import { createServer } from 'http'
import { Server } from 'socket.io'

const httpServer = createServer()
const io = new Server(httpServer, {
  // DO NOT change the path, it is used by Caddy to forward the request to the correct port
  path: '/',
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

// In-memory registry: socket.id -> { userId, role, name }
const onlineUsers = new Map()

// Map conversationId -> Set of socket.id currently in the room
const roomMembers = new Map()

function joinRoom(socket, conversationId) {
  const room = `conv:${conversationId}`
  socket.join(room)
  if (!roomMembers.has(room)) roomMembers.set(room, new Set())
  roomMembers.get(room).add(socket.id)
}

function leaveRoom(socket, conversationId) {
  const room = `conv:${conversationId}`
  socket.leave(room)
  if (roomMembers.has(room)) {
    roomMembers.get(room).delete(socket.id)
    if (roomMembers.get(room).size === 0) roomMembers.delete(room)
  }
}

io.on('connection', (socket) => {
  console.log(`[chat-service] connected: ${socket.id}`)

  // client emits "auth" with { userId, role, name }
  socket.on('auth', (payload) => {
    if (!payload || !payload.userId) return
    onlineUsers.set(socket.id, {
      userId: String(payload.userId),
      role: payload.role || 'PATIENT',
      name: payload.name || 'کاربر',
    })
    socket.emit('auth-ack', { ok: true })
  })

  // open a conversation room
  socket.on('open-conversation', ({ conversationId }) => {
    if (!conversationId) return
    joinRoom(socket, conversationId)
  })

  socket.on('close-conversation', ({ conversationId }) => {
    if (!conversationId) return
    leaveRoom(socket, conversationId)
  })

  // send a message; payload validated & persisted by Next.js API before emit
  socket.on('send-message', (payload) => {
    const { conversationId, message } = payload || {}
    if (!conversationId || !message) return
    // broadcast to room (including sender for echo)
    io.to(`conv:${conversationId}`).emit('new-message', message)
    // also broadcast a lightweight "conversation-updated" event so chat lists refresh
    io.to(`conv:${conversationId}`).emit('conversation-updated', {
      conversationId,
      lastMessage: message.content,
      senderId: message.senderId,
      senderRole: message.senderRole,
      createdAt: message.createdAt,
    })
  })

  // typing indicator
  socket.on('typing', ({ conversationId, isTyping }) => {
    if (!conversationId) return
    socket.to(`conv:${conversationId}`).emit('peer-typing', { conversationId, isTyping, from: onlineUsers.get(socket.id) })
  })

  // appointment status change broadcast (so patient side refreshes)
  socket.on('appointment-updated', ({ appointmentId, status, conversationId }) => {
    if (conversationId) {
      io.to(`conv:${conversationId}`).emit('appointment-status-changed', { appointmentId, status })
    }
  })

  socket.on('disconnect', () => {
    onlineUsers.delete(socket.id)
    // leave any rooms
    for (const [room, members] of roomMembers.entries()) {
      if (members.has(socket.id)) {
        members.delete(socket.id)
        if (members.size === 0) roomMembers.delete(room)
      }
    }
    console.log(`[chat-service] disconnected: ${socket.id}`)
  })

  socket.on('error', (err) => {
    console.error('[chat-service] socket error', err)
  })
})

const PORT = 3003
httpServer.listen(PORT, () => {
  console.log(`[chat-service] WebSocket server running on port ${PORT}`)
})

process.on('SIGTERM', () => {
  httpServer.close(() => process.exit(0))
})
process.on('SIGINT', () => {
  httpServer.close(() => process.exit(0))
})

---
Task ID: full
Agent: main (Super Z)
Task: ساخت سامانه نوبت‌دهی آنلاین مطب دندان‌پزشکی با پنل پزشک، مدیریت نوبت، تنظیم ساعات کاری و چت زنده.

Work Log:
- مقدارسازی محیط fullstack-dev (Next.js 16 + TS + Prisma + SQLite + shadcn/ui + Zustand)
- طراحی schema دیتابیس با ۴ مدل: User, WorkingHour, Appointment, Conversation, Message
- راه‌اندازی mini-service چت با Socket.io روی پورت ۳۰۰۳ با رویدادهای new-message، typing، conversation-updated
- ساخت API های: auth (login/register/logout/me)، working-hours، appointments، conversations/list، conversations/messages، doctors، slots، seed
- پیاده‌سازی فرم رزرو نوبت بیمار با انتخاب پزشک، انتخاب روز شمسی، نمایش تایم‌های خالی (محاسبه از ساعات کاری + نوبت‌های موجود)، و ثبت علت مراجعه
- ساخت پنل پزشک با تب‌های «در انتظار/تایید شده/سایر»، دکمه‌های تایید/رد/تکمیل/در انتظار، دیالوگ یادداشت
- ساخت مدیریت ساعات کاری هفتگی (شنبه تا جمعه) با اضافه/حذف/فعال-غیرفعال شیفت‌ها
- پیاده‌سازی چت زنده دوسویه با Socket.io و نمایش پیام‌های instant با bubble های متفاوت برای فرستنده/گیرنده
- رابط کاربری کاملاً فارسی و راست‌چین (RTL) با تم تیل (teal) و کاملاً ریسپانسیو
- seed خودکار دکتر دمو (دکتر سارا محمدی، ۰۹۱۲۰۰۰۰۰۰۰، ۱۲۳۴۵۶) با ساعات کاری شنبه تا چهارشنبه + بیمار دمو (۰۹۱۲۱۱۱۱۱۱۱، ۱۲۳۴۵۶)
- تست end-to-end با Agent Browser: ورود پزشک، نمایش ساعات کاری، خروج؛ ورود بیمار، انتخاب روز، رزرو نوبت، ورود پزشک مجدداً، تایید نوبت با یادداشت، چت با بیمار

Stage Summary:
- ساختار پروژه: 4 کامپوننت اصلی (AuthDialog، BookingForm، PatientAppointments، DoctorAppointments، WorkingHoursManager، ChatPanel، ConversationList)
- API routes: 8 اندپوینت REST + 1 mini-service Socket.io
- دیتابیس: SQLite با 5 جدول (User, WorkingHour, Appointment, Conversation, Message)
- احراز هویت: Session-based با توکن تصادفی و header `x-session-token`
- تاریخ: تبدیل Gregorian <-> Jalali با Intl.DateTimeFormat + نمایش اعداد فارسی
- وضعیت تست: تمام مسیرهای طلایی (golden paths) با موفقیت تست شدند - رزرو، تایید، چت همگی کار می‌کنند
- لینت بدون خطا (eslint clean)
- سرویس‌ها در حال اجرا: Next.js روی ۳۰۰۰، chat-service روی ۳۰۰۳

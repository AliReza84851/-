'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type Role = 'PATIENT' | 'DOCTOR'

export interface AuthUser {
  id: string
  role: Role
  name: string
  phone: string
  email?: string | null
  specialty?: string | null
}

interface AppState {
  token: string | null
  user: AuthUser | null
  view: 'home' | 'book' | 'my-appointments' | 'manage-appointments' | 'working-hours' | 'chat'
  activeConversationId: string | null
  setAuth: (token: string, user: AuthUser) => void
  clearAuth: () => void
  setView: (v: AppState['view']) => void
  setActiveConversationId: (id: string | null) => void
}

export const useApp = create<AppState>()(
  persist(
    (set) => ({
      token: null,
      user: null,
      view: 'home',
      activeConversationId: null,
      setAuth: (token, user) => set({ token, user, view: 'home', activeConversationId: null }),
      clearAuth: () => set({ token: null, user: null, view: 'home' }),
      setView: (view) => set({ view }),
      setActiveConversationId: (activeConversationId) => set({ activeConversationId }),
    }),
    { name: 'dental-clinic-state' }
  )
)

export async function api<T = any>(
  path: string,
  opts: RequestInit = {},
  token?: string | null
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(opts.headers as any),
  }
  if (token) headers['x-session-token'] = token
  const res = await fetch(path, { ...opts, headers })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    throw new Error((data as any).error || `HTTP ${res.status}`)
  }
  return data as T
}

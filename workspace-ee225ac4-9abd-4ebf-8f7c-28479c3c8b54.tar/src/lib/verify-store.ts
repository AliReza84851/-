// In-memory stores for verification codes and verified tokens.
// Reset on server restart. For production use Redis or DB.

export interface CodeEntry {
  code: string
  expires: number
}

export interface VerifiedEntry {
  phone: string
  expires: number
}

const codes = new Map<string, CodeEntry>()
const verifiedTokens = new Map<string, VerifiedEntry>()

export function getCodesStore(): Map<string, CodeEntry> {
  return codes
}

export function getVerifiedStore(): Map<string, VerifiedEntry> {
  return verifiedTokens
}

export function gen6(): string {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

// In-memory block list (userId -> Set of blocked userIds)
const blockList = new Map<string, Set<string>>()

export function isBlocked(userIdA: string, userIdB: string): boolean {
  const aBlocks = blockList.get(userIdA)
  if (aBlocks && aBlocks.has(userIdB)) return true
  const bBlocks = blockList.get(userIdB)
  if (bBlocks && bBlocks.has(userIdA)) return true
  return false
}

export function getBlockListStore(): Map<string, Set<string>> {
  return blockList
}

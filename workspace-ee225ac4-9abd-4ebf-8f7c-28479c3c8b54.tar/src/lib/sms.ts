// SMS service abstraction
// Supports: Kavenegar, MeliPayamak, Farapayamak, Twilio, or any HTTP-based SMS gateway
// Configure via environment variables in .env file:
//   SMS_PROVIDER=kavenegar  (or melipayamak, farapayamak, twilio, none)
//   SMS_API_KEY=your_api_key
//   SMS_SENDER_NUMBER=your_sender_number (for melipayamak/farapayamak)
//   SMS_FROM=optional_from (for twilio)
//
// If SMS_PROVIDER is not set or "none", the SMS is NOT sent and the code
// is returned via `devCode` for testing purposes.

export type SMSProvider = 'kavenegar' | 'melipayamak' | 'farapayamak' | 'twilio' | 'none'

interface SMSResult {
  sent: boolean
  message: string
  devCode?: string // shown only when not actually sent
}

export function getSMSProvider(): SMSProvider {
  const p = (process.env.SMS_PROVIDER || 'none').toLowerCase() as SMSProvider
  if (!['kavenegar', 'melipayamak', 'farapayamak', 'twilio', 'none'].includes(p)) {
    return 'none'
  }
  return p
}

// Normalize Iranian phone: 09123456789 -> 989123456789
function normalizeIranPhone(phone: string): string {
  const trimmed = phone.trim()
  if (trimmed.startsWith('09')) return '98' + trimmed.slice(1)
  if (trimmed.startsWith('989')) return trimmed
  if (trimmed.startsWith('+989')) return trimmed.slice(1)
  return trimmed
}

export async function sendVerificationCode(phone: string, code: string): Promise<SMSResult> {
  const provider = getSMSProvider()
  const apiKey = process.env.SMS_API_KEY || ''
  const sender = process.env.SMS_SENDER_NUMBER || ''
  const from = process.env.SMS_FROM || ''

  if (provider === 'none' || !apiKey) {
    // Dev mode: don't actually send, return the code so UI can display it
    return {
      sent: false,
      message: 'کد در حالت دمو نمایش داده می‌شود. برای ارسال واقعی، SMS_PROVIDER و SMS_API_KEY را در .env تنظیم کنید.',
      devCode: code,
    }
  }

  try {
    switch (provider) {
      case 'kavenegar':
        await sendKavenegar(apiKey, phone, code)
        break
      case 'melipayamak':
        await sendMelipayamak(apiKey, sender, phone, code)
        break
      case 'farapayamak':
        await sendFarapayamak(apiKey, sender, phone, code)
        break
      case 'twilio':
        await sendTwilio(apiKey, from, phone, code)
        break
    }
    return { sent: true, message: 'کد تأیید به شماره شما ارسال شد' }
  } catch (e: any) {
    // If SMS sending fails, fall back to dev mode so the user can still test
    return {
      sent: false,
      message: 'ارسال پیامک ناموفق بود: ' + (e?.message || 'unknown'),
      devCode: code,
    }
  }
}

// Kavenegar SMS gateway
async function sendKavenegar(apiKey: string, phone: string, code: string) {
  const receptor = normalizeIranPhone(phone)
  const message = `کد تأیید شما در سامانه نوبت‌دهی مطب دندان‌پزشکی: ${code}`
  const url = `https://api.kavenegar.com/v1/${apiKey}/sms/send.json`
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ receptor, message }).toString(),
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`Kavenegar error: ${res.status} ${text}`)
  }
  const data = await res.json().catch(() => ({}))
  if (data?.return?.status && data.return.status !== 200) {
    throw new Error(`Kavenegar: ${data.return.message || 'unknown error'}`)
  }
}

// Melipayamak SMS gateway
async function sendMelipayamak(apiKey: string, sender: string, phone: string, code: string) {
  const receptor = normalizeIranPhone(phone)
  const message = `کد تأیید شما در سامانه نوبت‌دهی مطب دندان‌پزشکی: ${code}`
  // Melipayamak expects: username:password in apiKey (separated by colon)
  const [username, password] = apiKey.split(':')
  if (!username || !password) {
    throw new Error('Melipayamak: SMS_API_KEY should be in "username:password" format')
  }
  const res = await fetch('https://rest.payamak-panel.com/api/SendSMS/SendSMS', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password, text: message, to: receptor, from: sender }),
  })
  if (!res.ok) throw new Error(`Melipayamak: ${res.status}`)
}

// Farapayamak SMS gateway
async function sendFarapayamak(apiKey: string, sender: string, phone: string, code: string) {
  const receptor = normalizeIranPhone(phone)
  const message = `کد تأیید شما در سامانه نوبت‌دهی مطب دندان‌پزشکی: ${code}`
  const [username, password] = apiKey.split(':')
  if (!username || !password) {
    throw new Error('Farapayamak: SMS_API_KEY should be in "username:password" format')
  }
  const res = await fetch('https://api.ippanel.com/api/v1/sms/send/simple', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({ from: sender, to: receptor, text: message }),
  })
  if (!res.ok) throw new Error(`Farapayamak: ${res.status}`)
}

// Twilio SMS gateway
async function sendTwilio(apiKey: string, from: string, phone: string, code: string) {
  const [accountSid, authToken] = apiKey.split(':')
  if (!accountSid || !authToken) {
    throw new Error('Twilio: SMS_API_KEY should be in "accountSid:authToken" format')
  }
  const message = `Your dental clinic verification code: ${code}`
  const url = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: 'Basic ' + Buffer.from(`${accountSid}:${authToken}`).toString('base64'),
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({ From: from, To: phone, Body: message }).toString(),
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`Twilio: ${res.status} ${text}`)
  }
}

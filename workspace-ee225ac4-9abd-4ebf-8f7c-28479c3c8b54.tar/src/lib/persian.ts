// Persian utilities
export const PERSIAN_DAYS = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه']

export function toPersianDigits(s: string | number): string {
  const map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹']
  return String(s).replace(/[0-9]/g, (d) => map[Number(d)])
}

// Convert ISO date (YYYY-MM-DD) -> Persian Jalali date string using Intl
export function toJalali(isoDate: string): string {
  try {
    const d = new Date(isoDate + 'T00:00:00')
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      weekday: 'long',
    }).format(d)
  } catch {
    return isoDate
  }
}

export function formatTime(t: string): string {
  return toPersianDigits(t)
}

// Convert Gregorian Date to Jalali YYYY-MM-DD using Intl
export function toJalaliISO(date: Date): string {
  // returns a "YYYY-MM-DD" Persian-calendar string
  const parts = new Intl.DateTimeFormat('en-US-u-ca-persian', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date)
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? ''
  let y = get('year')
  let m = get('month')
  let d = get('day')
  // Intl may return Persian digits; normalize to ASCII
  const faToEn = (s: string) => s.replace(/[۰-۹]/g, (x) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(x)))
  y = faToEn(y)
  m = faToEn(m)
  d = faToEn(d)
  return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`
}

// Convert Jalali ISO "YYYY-MM-DD" back to Gregorian ISO used by server.
// Uses Intl with calendar=persian and year/month/day numbers.
export function jalaliToGregorian(jalaliISO: string): string {
  const [y, m, d] = jalaliISO.split('-').map(Number)
  // Build a date using Persian calendar — Intl will convert from "Persian date" notation
  // We approximate: use `new Date(Date.UTC(...))` with a fixed lookup since Persian calendar
  // leap years differ. Easiest: compute via Intl with "fa-IR-u-ca-persian" using parts.
  // Trick: format using Persian calendar from a guessed Gregorian, then iterate to match.
  // Simpler: Use built-in Intl to set parts.
  // Actually, JS Intl cannot *construct* a Date from Persian parts directly.
  // We'll do a small iteration to find the Gregorian date whose Persian Y/M/D matches.
  let guess = new Date(Date.UTC(2024, 0, 1))
  for (let i = 0; i < 366 * 30; i++) {
    const g = new Date(guess.getTime() + i * 86400000)
    const parts = new Intl.DateTimeFormat('en-US-u-ca-persian', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).formatToParts(g)
    const get = (t: string) => Number(parts.find((p) => p.type === t)?.value ?? '0')
    if (get('year') === y && get('month') === m && get('day') === d) {
      // return YYYY-MM-DD in Gregorian
      const gy = g.getFullYear()
      const gm = String(g.getMonth() + 1).padStart(2, '0')
      const gd = String(g.getDate()).padStart(2, '0')
      return `${gy}-${gm}-${gd}`
    }
  }
  // fallback: return as-is
  return jalaliISO
}

// Get the next 14 days in Gregorian ISO with a Persian label
export interface DayOption {
  greg: string // YYYY-MM-DD Gregorian
  label: string // Persian label like "۱۴۰۳/۰۷/۲۲ - شنبه"
  jalaliISO: string // Jalali YYYY-MM-DD
  disabled: boolean
}

export function getNextDays(count: number): DayOption[] {
  const arr: DayOption[] = []
  const today = new Date()
  for (let i = 0; i < count; i++) {
    const d = new Date(today)
    d.setDate(today.getDate() + i)
    const greg = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
    const jalaliISO = toJalaliISO(d)
    const weekday = new Intl.DateTimeFormat('fa-IR', { weekday: 'long' }).format(d)
    const label = `${toPersianDigits(jalaliISO)} - ${weekday}`
    arr.push({ greg, label, jalaliISO, disabled: false })
  }
  return arr
}

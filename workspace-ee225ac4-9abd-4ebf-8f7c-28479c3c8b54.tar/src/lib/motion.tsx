import { motion, useReducedMotion } from 'framer-motion'
import { useEffect, useRef, useState } from 'react'

// Shared easing curve — smooth, modern spring-like ease
export const EASE = [0.22, 1, 0.36, 1] as const
export const SPRING = { type: 'spring', stiffness: 300, damping: 24 } as const
export const SPRING_SOFT = { type: 'spring', stiffness: 260, damping: 28 } as const

// Stagger container — children fade/slide in one after another
export const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.07, delayChildren: 0.05 },
  },
}

// Standard item variant — fade + slide up
export const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: EASE } },
}

// Scale-in variant — for cards/badges
export const scaleVariants = {
  hidden: { opacity: 0, scale: 0.92 },
  show: { opacity: 1, scale: 1, transition: { duration: 0.4, ease: EASE } },
}

// Slide from right (for RTL content)
export const slideFromRight = {
  hidden: { opacity: 0, x: 24 },
  show: { opacity: 1, x: 0, transition: { duration: 0.45, ease: EASE } },
}

// Page transition wrapper for view switching
export const pageTransition = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -12 },
  transition: { duration: 0.3, ease: EASE },
}

// Animated number counter — counts up from 0 to target
export function AnimatedNumber({ value, duration = 0.8 }: { value: number; duration?: number }) {
  const reduce = useReducedMotion()
  const [display, setDisplay] = useState(0)
  const prev = useRef(0)

  useEffect(() => {
    if (reduce) {
      prev.current = value
      return
    }
    const from = prev.current
    const to = value
    const start = performance.now()
    let raf = 0
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / (duration * 1000))
      // easeOutCubic
      const eased = 1 - Math.pow(1 - t, 3)
      setDisplay(Math.round(from + (to - from) * eased))
      if (t < 1) raf = requestAnimationFrame(tick)
      else prev.current = to
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [value, duration, reduce])

  // When reduced motion is on, show the final value directly without animation state
  const shown = reduce ? value : display
  return <>{toPersianDigitsLocal(shown)}</>
}

// local digit conversion to avoid circular import
function toPersianDigitsLocal(s: number | string): string {
  const map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹']
  return String(s).replace(/[0-9]/g, (d) => map[Number(d)])
}

// Re-export motion for convenience
export { motion }

import { db } from '@/lib/db'

export const SESSION_COOKIE = 'dc_session'

export interface SessionPayload {
  userId: string
  role: 'DOCTOR' | 'PATIENT'
  name: string
}

// Very small in-memory session store keyed by random token.
// Fine for this single-instance demo; reset on server restart.
const sessions = new Map<string, SessionPayload>()

export function createSession(payload: SessionPayload): string {
  const token =
    Math.random().toString(36).slice(2) + Date.now().toString(36) + Math.random().toString(36).slice(2)
  sessions.set(token, payload)
  return token
}

export function getSession(token?: string | null): SessionPayload | null {
  if (!token) return null
  return sessions.get(token) ?? null
}

export function destroySession(token?: string | null): void {
  if (!token) return
  sessions.delete(token)
}

export async function getCurrentUser(req: Request): Promise<SessionPayload | null> {
  const token = req.headers.get('x-session-token') || undefined
  return getSession(token)
}

export async function getDoctor(req: Request) {
  const s = await getCurrentUser(req)
  if (!s || s.role !== 'DOCTOR') return null
  return s
}

export async function getPatient(req: Request) {
  const s = await getCurrentUser(req)
  if (!s || s.role !== 'PATIENT') return null
  return s
}

export async function getUserById(userId: string) {
  return db.user.findUnique({
    where: { id: userId },
    select: { id: true, role: true, name: true, phone: true, email: true, specialty: true },
  })
}

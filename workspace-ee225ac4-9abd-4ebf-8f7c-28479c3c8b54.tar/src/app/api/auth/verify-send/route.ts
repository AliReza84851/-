import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCodesStore, gen6 } from '@/lib/verify-store'
import { sendVerificationCode, getSMSProvider } from '@/lib/sms'

// POST /api/auth/verify-send
// Body: { phone, mode: 'register' | 'login' }
// Sends a verification code to the user's phone via SMS.
// In dev mode (no SMS provider configured), the code is returned in `devCode` for testing.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const phone = String(body?.phone || '').trim()
    const mode = body?.mode === 'login' ? 'login' : 'register'
    if (!/^09\d{9}$/.test(phone)) {
      return NextResponse.json({ error: 'شماره موبایل معتبر نیست (مثال: 09123456789)' }, { status: 400 })
    }

    if (mode === 'register') {
      const existing = await db.user.findUnique({ where: { phone } })
      if (existing) {
        return NextResponse.json({ error: 'این شماره قبلاً ثبت شده است. وارد شوید.' }, { status: 400 })
      }
    } else {
      const user = await db.user.findUnique({ where: { phone } })
      if (!user) {
        return NextResponse.json({ error: 'این شماره ثبت نشده است. ابتدا ثبت‌نام کنید.' }, { status: 400 })
      }
    }

    const code = gen6()
    const expires = Date.now() + 2 * 60 * 1000
    getCodesStore().set(phone, { code, expires })

    // Actually send the SMS (or fall back to dev mode)
    const result = await sendVerificationCode(phone, code)
    const provider = getSMSProvider()

    return NextResponse.json({
      ok: true,
      message: result.message,
      sent: result.sent,
      devCode: result.devCode || null, // only present when not actually sent
      provider: provider === 'none' ? 'demo' : provider,
      expiresIn: 120,
    })
  } catch (e: any) {
    return NextResponse.json({ error: 'خطای سرور: ' + (e?.message ?? 'unknown') }, { status: 500 })
  }
}

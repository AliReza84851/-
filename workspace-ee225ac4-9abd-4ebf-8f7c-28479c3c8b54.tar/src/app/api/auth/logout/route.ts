import { NextRequest, NextResponse } from 'next/server'
import { destroySession } from '@/lib/auth'

export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session-token') || undefined
  destroySession(token)
  return NextResponse.json({ ok: true })
}

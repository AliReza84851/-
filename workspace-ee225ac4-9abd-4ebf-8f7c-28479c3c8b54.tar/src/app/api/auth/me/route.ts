import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const s = await getCurrentUser(req)
  if (!s) return NextResponse.json({ user: null })
  const u = await db.user.findUnique({
    where: { id: s.userId },
    select: { id: true, role: true, name: true, phone: true, email: true, specialty: true },
  })
  return NextResponse.json({ user: u })
}

import { NextRequest, NextResponse } from 'next/server'
import { getCodesStore, getVerifiedStore } from '@/lib/verify-store'

// POST /api/auth/verify-check
// Body: { phone, code }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const phone = String(body?.phone || '').trim()
    const code = String(body?.code || '').trim()
    if (!phone || !code) {
      return NextResponse.json({ error: 'شماره و کد الزامی است' }, { status: 400 })
    }

    const codes = getCodesStore()
    const entry = codes.get(phone)
    if (!entry) {
      return NextResponse.json({ error: 'ابتدا کد را دریافت کنید' }, { status: 400 })
    }
    if (Date.now() > entry.expires) {
      codes.delete(phone)
      return NextResponse.json({ error: 'کد منقضی شده است. دوباره درخواست کنید.' }, { status: 400 })
    }
    if (entry.code !== code) {
      return NextResponse.json({ error: 'کد وارد شده نادرست است' }, { status: 400 })
    }

    codes.delete(phone)
    const verifiedToken =
      Math.random().toString(36).slice(2) + Date.now().toString(36) + Math.random().toString(36).slice(2)
    getVerifiedStore().set(verifiedToken, { phone, expires: Date.now() + 5 * 60 * 1000 })
    return NextResponse.json({ ok: true, verifiedToken })
  } catch (e: any) {
    return NextResponse.json({ error: 'خطای سرور: ' + (e?.message ?? 'unknown') }, { status: 500 })
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createSession } from '@/lib/auth'
import { getVerifiedStore } from '@/lib/verify-store'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { name, phone, password, email, role, specialty, verifiedToken } = body || {}
    if (!name || !phone || !password) {
      return NextResponse.json({ error: 'نام، شماره موبایل و رمز عبور الزامی است' }, { status: 400 })
    }
    if (!['PATIENT', 'DOCTOR'].includes(role)) {
      return NextResponse.json({ error: 'نقش نامعتبر است' }, { status: 400 })
    }
    if (!verifiedToken) {
      return NextResponse.json({ error: 'ابتدا شماره موبایل خود را با کد تأیید کنید' }, { status: 400 })
    }

    // Verify the verifiedToken
    const verified = getVerifiedStore().get(String(verifiedToken))
    if (!verified) {
      return NextResponse.json({ error: 'تأیید شماره معتبر نیست یا منقضی شده. دوباره کد دریافت کنید.' }, { status: 400 })
    }
    if (Date.now() > verified.expires) {
      getVerifiedStore().delete(String(verifiedToken))
      return NextResponse.json({ error: 'تأیید شماره منقضی شده. دوباره کد دریافت کنید.' }, { status: 400 })
    }
    if (verified.phone !== String(phone).trim()) {
      return NextResponse.json({ error: 'شماره با تأیید شده مطابقت ندارد' }, { status: 400 })
    }
    getVerifiedStore().delete(String(verifiedToken))

    const existing = await db.user.findUnique({ where: { phone: String(phone).trim() } })
    if (existing) {
      return NextResponse.json({ error: 'این شماره موبایل قبلاً ثبت شده است' }, { status: 400 })
    }
    const user = await db.user.create({
      data: {
        name: String(name).trim(),
        phone: String(phone).trim(),
        password: String(password),
        email: email ? String(email) : null,
        role: String(role),
        specialty: role === 'DOCTOR' && specialty ? String(specialty) : null,
      },
    })
    const token = createSession({ userId: user.id, role: user.role as 'DOCTOR' | 'PATIENT', name: user.name })
    return NextResponse.json({
      token,
      user: {
        id: user.id,
        role: user.role,
        name: user.name,
        phone: user.phone,
        email: user.email,
        specialty: user.specialty,
      },
    })
  } catch (e: any) {
    return NextResponse.json({ error: 'خطای سرور: ' + (e?.message ?? 'unknown') }, { status: 500 })
  }
}

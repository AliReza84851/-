import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createSession } from '@/lib/auth'

// POST /api/auth/login
// Body: { phone, password } - no verification code required for login
// (phone verification is only required at registration time)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { phone, password } = body || {}
    if (!phone || !password) {
      return NextResponse.json({ error: 'شماره موبایل و رمز عبور الزامی است' }, { status: 400 })
    }

    const user = await db.user.findUnique({ where: { phone: String(phone).trim() } })
    if (!user || user.password !== String(password)) {
      return NextResponse.json({ error: 'شماره موبایل یا رمز عبور نادرست است' }, { status: 401 })
    }
    const token = createSession({ userId: user.id, role: user.role as 'DOCTOR' | 'PATIENT', name: user.name })
    return NextResponse.json({
      token,
      user: {
        id: user.id,
        role: user.role,
        name: user.name,
        phone: user.phone,
        email: user.email,
        specialty: user.specialty,
      },
    })
  } catch (e: any) {
    return NextResponse.json({ error: 'خطای سرور: ' + (e?.message ?? 'unknown') }, { status: 500 })
  }
}

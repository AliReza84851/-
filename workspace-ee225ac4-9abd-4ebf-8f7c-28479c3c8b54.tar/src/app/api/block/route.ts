import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { getBlockListStore } from '@/lib/verify-store'

// POST /api/block { blockedUserId } - block a user
// DELETE /api/block?blockedUserId=... - unblock
// GET /api/block - list blocked users
export async function POST(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me) return NextResponse.json({ error: 'ابتدا وارد شوید' }, { status: 401 })
  const body = await req.json()
  const blockedUserId = String(body?.blockedUserId || '')
  if (!blockedUserId || blockedUserId === me.userId) {
    return NextResponse.json({ error: 'کاربر نامعتبر است' }, { status: 400 })
  }

  const target = await db.user.findUnique({ where: { id: blockedUserId }, select: { id: true, name: true } })
  if (!target) return NextResponse.json({ error: 'کاربر یافت نشد' }, { status: 404 })

  const store = getBlockListStore()
  if (!store.has(me.userId)) store.set(me.userId, new Set())
  store.get(me.userId)!.add(blockedUserId)
  return NextResponse.json({ ok: true, blocked: { id: target.id, name: target.name } })
}

export async function DELETE(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me) return NextResponse.json({ error: 'ابتدا وارد شوید' }, { status: 401 })
  const url = new URL(req.url)
  const blockedUserId = url.searchParams.get('blockedUserId')
  if (!blockedUserId) return NextResponse.json({ error: 'blockedUserId الزامی' }, { status: 400 })
  const store = getBlockListStore()
  if (store.has(me.userId)) {
    store.get(me.userId)!.delete(blockedUserId)
  }
  return NextResponse.json({ ok: true })
}

export async function GET(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me) return NextResponse.json({ error: 'ابتدا وارد شوید' }, { status: 401 })
  const store = getBlockListStore()
  const blockedIds = Array.from(store.get(me.userId) || new Set())
  const blocked = await db.user.findMany({
    where: { id: { in: blockedIds } },
    select: { id: true, name: true, phone: true, role: true },
  })
  return NextResponse.json({ blocked })
}

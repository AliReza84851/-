import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'

// GET /api/appointments?role=PATIENT|DOCTOR  -> returns appointments for current user
// If role=PATIENT, returns appointments of the patient.
// If role=DOCTOR, returns appointments for this doctor.
export async function GET(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me) return NextResponse.json({ error: 'ابتدا وارد شوید' }, { status: 401 })
  const url = new URL(req.url)
  const status = url.searchParams.get('status')

  const where: any = {}
  if (me.role === 'PATIENT') where.patientId = me.userId
  else where.doctorId = me.userId
  if (status) where.status = String(status).toUpperCase()

  const appts = await db.appointment.findMany({
    where,
    include: {
      doctor: { select: { id: true, name: true, specialty: true, phone: true } },
      patient: { select: { id: true, name: true, phone: true } },
    },
    orderBy: [{ date: 'asc' }, { startTime: 'asc' }],
  })

  return NextResponse.json({ appointments: appts })
}

// POST /api/appointments - create new appointment (patient)
export async function POST(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me) return NextResponse.json({ error: 'ابتدا وارد شوید' }, { status: 401 })
  const body = await req.json()
  const { doctorId, date, startTime, endTime, reason } = body || {}
  if (!doctorId || !date || !startTime || !endTime) {
    return NextResponse.json({ error: 'اطلاعات نوبت ناقص است' }, { status: 400 })
  }
  // Check slot not already taken
  const conflict = await db.appointment.findFirst({
    where: {
      doctorId: String(doctorId),
      date: String(date),
      startTime: String(startTime),
      status: { in: ['PENDING', 'APPROVED'] },
    },
  })
  if (conflict) {
    return NextResponse.json({ error: 'این تایم قبلاً رزرو شده است' }, { status: 409 })
  }
  // Ensure patient is a PATIENT (or set role to patient for booking)
  const appt = await db.appointment.create({
    data: {
      doctorId: String(doctorId),
      patientId: me.userId,
      date: String(date),
      startTime: String(startTime),
      endTime: String(endTime),
      reason: String(reason || ''),
      status: 'PENDING',
    },
    include: {
      doctor: { select: { id: true, name: true, specialty: true } },
      patient: { select: { id: true, name: true, phone: true } },
    },
  })
  return NextResponse.json({ appointment: appt })
}

// PATCH /api/appointments?id=... { status, note } - doctor updates status
export async function PATCH(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me || me.role !== 'DOCTOR') {
    return NextResponse.json({ error: 'دسترسی فقط برای پزشک' }, { status: 403 })
  }
  const url = new URL(req.url)
  const id = url.searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'id الزامی است' }, { status: 400 })
  const body = await req.json()
  const { status, note } = body || {}
  const valid = ['PENDING', 'APPROVED', 'REJECTED', 'COMPLETED', 'CANCELLED']
  if (!valid.includes(String(status))) {
    return NextResponse.json({ error: 'وضعیت نامعتبر است' }, { status: 400 })
  }
  const existing = await db.appointment.findUnique({ where: { id } })
  if (!existing || existing.doctorId !== me.userId) {
    return NextResponse.json({ error: 'نوبت یافت نشد' }, { status: 404 })
  }
  const updated = await db.appointment.update({
    where: { id },
    data: {
      status: String(status),
      note: note !== undefined ? String(note) : existing.note,
    },
    include: {
      doctor: { select: { id: true, name: true, specialty: true } },
      patient: { select: { id: true, name: true, phone: true } },
    },
  })
  return NextResponse.json({ appointment: updated })
}

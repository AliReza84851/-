import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// POST /api/seed - seed demo doctor + working hours (idempotent)
export async function POST() {
  const phone = '09120000000'
  let doctor = await db.user.findUnique({ where: { phone } })
  if (!doctor) {
    doctor = await db.user.create({
      data: {
        name: 'دکتر سارا محمدی',
        phone,
        password: '123456',
        role: 'DOCTOR',
        specialty: 'دندان‌پزشک عمومی',
        email: 'sara@clinic.local',
      },
    })
  } else if (doctor.role !== 'DOCTOR') {
    doctor = await db.user.update({
      where: { id: doctor.id },
      data: { role: 'DOCTOR', specialty: 'دندان‌پزشک عمومی', password: '123456' },
    })
  }

  // Saturday..Wednesday 9-13, 16-20 ; Thursday 9-13
  const defaults = [
    { dayOfWeek: 0, startTime: '09:00', endTime: '13:00' },
    { dayOfWeek: 0, startTime: '16:00', endTime: '20:00' },
    { dayOfWeek: 1, startTime: '09:00', endTime: '13:00' },
    { dayOfWeek: 1, startTime: '16:00', endTime: '20:00' },
    { dayOfWeek: 2, startTime: '09:00', endTime: '13:00' },
    { dayOfWeek: 2, startTime: '16:00', endTime: '20:00' },
    { dayOfWeek: 3, startTime: '09:00', endTime: '13:00' },
    { dayOfWeek: 3, startTime: '16:00', endTime: '20:00' },
    { dayOfWeek: 4, startTime: '09:00', endTime: '13:00' },
    { dayOfWeek: 5, startTime: '09:00', endTime: '13:00' },
  ]
  for (const d of defaults) {
    const existing = await db.workingHour.findFirst({
      where: { doctorId: doctor.id, dayOfWeek: d.dayOfWeek, startTime: d.startTime },
    })
    if (!existing) {
      await db.workingHour.create({
        data: { doctorId: doctor.id, dayOfWeek: d.dayOfWeek, startTime: d.startTime, endTime: d.endTime, slotMinutes: 30 },
      })
    }
  }

  // Demo patient
  const pPhone = '09121111111'
  let patient = await db.user.findUnique({ where: { phone: pPhone } })
  if (!patient) {
    patient = await db.user.create({
      data: { name: 'بیمار نمونه', phone: pPhone, password: '123456', role: 'PATIENT' },
    })
  }

  return NextResponse.json({
    ok: true,
    doctor: { phone: doctor.phone, password: '123456', name: doctor.name, specialty: doctor.specialty },
    patient: { phone: patient.phone, password: '123456', name: patient.name },
  })
}

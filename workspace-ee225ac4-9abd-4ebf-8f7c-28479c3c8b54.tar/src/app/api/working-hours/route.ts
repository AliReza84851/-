import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'

// GET /api/working-hours?doctorId=...
// If no doctorId provided and user is a doctor, returns own hours.
export async function GET(req: NextRequest) {
  const url = new URL(req.url)
  const doctorId = url.searchParams.get('doctorId')
  const me = await getCurrentUser(req)

  let targetDoctorId = doctorId || (me?.role === 'DOCTOR' ? me.userId : null)
  if (!targetDoctorId) {
    // return working hours for all doctors
    const all = await db.workingHour.findMany({
      where: { isActive: true },
      include: { doctor: { select: { id: true, name: true, specialty: true } } },
      orderBy: [{ dayOfWeek: 'asc' }, { startTime: 'asc' }],
    })
    return NextResponse.json({ workingHours: all })
  }
  const hours = await db.workingHour.findMany({
    where: { doctorId: targetDoctorId },
    orderBy: [{ dayOfWeek: 'asc' }, { startTime: 'asc' }],
  })
  return NextResponse.json({ workingHours: hours, doctorId: targetDoctorId })
}

// POST /api/working-hours (doctor only) - create or upsert
export async function POST(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me || me.role !== 'DOCTOR') {
    return NextResponse.json({ error: 'دسترسی فقط برای پزشک فراهم است' }, { status: 403 })
  }
  const body = await req.json()
  const { dayOfWeek, startTime, endTime, slotMinutes = 30, isActive = true, id } = body || {}
  if (dayOfWeek == null || !startTime || !endTime) {
    return NextResponse.json({ error: 'روز، شروع و پایان الزامی است' }, { status: 400 })
  }
  if (id) {
    const updated = await db.workingHour.update({
      where: { id: String(id) },
      data: { dayOfWeek, startTime, endTime, slotMinutes, isActive },
    })
    return NextResponse.json({ workingHour: updated })
  }
  // upsert by (doctorId, dayOfWeek, startTime)
  const existing = await db.workingHour.findFirst({
    where: { doctorId: me.userId, dayOfWeek: Number(dayOfWeek), startTime: String(startTime) },
  })
  if (existing) {
    const updated = await db.workingHour.update({
      where: { id: existing.id },
      data: { endTime: String(endTime), slotMinutes: Number(slotMinutes), isActive: Boolean(isActive) },
    })
    return NextResponse.json({ workingHour: updated })
  }
  const created = await db.workingHour.create({
    data: {
      doctorId: me.userId,
      dayOfWeek: Number(dayOfWeek),
      startTime: String(startTime),
      endTime: String(endTime),
      slotMinutes: Number(slotMinutes) || 30,
      isActive: Boolean(isActive),
    },
  })
  return NextResponse.json({ workingHour: created })
}

// DELETE /api/working-hours?id=...
export async function DELETE(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me || me.role !== 'DOCTOR') {
    return NextResponse.json({ error: 'دسترسی فقط برای پزشک' }, { status: 403 })
  }
  const url = new URL(req.url)
  const id = url.searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'id الزامی است' }, { status: 400 })
  await db.workingHour.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}

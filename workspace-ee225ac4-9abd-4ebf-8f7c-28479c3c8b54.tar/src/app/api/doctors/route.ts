import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/doctors - list all doctors with working hours count
export async function GET() {
  const doctors = await db.user.findMany({
    where: { role: 'DOCTOR' },
    select: {
      id: true,
      name: true,
      specialty: true,
      phone: true,
      email: true,
      workingHours: { where: { isActive: true } },
    },
  })
  return NextResponse.json({
    doctors: doctors.map((d) => ({
      id: d.id,
      name: d.name,
      specialty: d.specialty,
      phone: d.phone,
      email: d.email,
      hasHours: d.workingHours.length > 0,
      hoursCount: d.workingHours.length,
    })),
  })
}

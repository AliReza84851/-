import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { isBlocked } from '@/lib/verify-store'

// GET /api/conversations/messages?conversationId=...
export async function GET(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me) return NextResponse.json({ error: 'ابتدا وارد شوید' }, { status: 401 })
  const url = new URL(req.url)
  const conversationId = url.searchParams.get('conversationId')
  if (!conversationId) return NextResponse.json({ error: 'conversationId الزامی' }, { status: 400 })

  // verify membership
  const conv = await db.conversation.findUnique({ where: { id: conversationId } })
  if (!conv || (conv.doctorId !== me.userId && conv.patientId !== me.userId)) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  const messages = await db.message.findMany({
    where: { conversationId },
    orderBy: { createdAt: 'asc' },
  })

  // mark received messages as read
  await db.message.updateMany({
    where: { conversationId, senderId: { not: me.userId }, isRead: false },
    data: { isRead: true },
  })

  return NextResponse.json({ messages })
}

// POST /api/conversations/messages { conversationId, content } - persist + return the new message
// The client then emits 'send-message' to the socket.io server to broadcast to peers.
export async function POST(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me) return NextResponse.json({ error: 'ابتدا وارد شوید' }, { status: 401 })
  const body = await req.json()
  const { conversationId, content } = body || {}
  if (!conversationId || !content) return NextResponse.json({ error: 'اطلاعات ناقص' }, { status: 400 })

  const conv = await db.conversation.findUnique({ where: { id: String(conversationId) } })
  if (!conv || (conv.doctorId !== me.userId && conv.patientId !== me.userId)) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  // Check if either party blocked the other
  const peerId = conv.doctorId === me.userId ? conv.patientId : conv.doctorId
  if (isBlocked(me.userId, peerId)) {
    return NextResponse.json({ error: 'کاربر را مسدود کرده‌اید. برای ارسال پیام ابتدا رفع مسدودیت کنید.' }, { status: 403 })
  }
  if (isBlocked(peerId, me.userId)) {
    return NextResponse.json({ error: 'این کاربر شما را مسدود کرده است' }, { status: 403 })
  }

  const msg = await db.message.create({
    data: {
      conversationId: String(conversationId),
      senderId: me.userId,
      content: String(content),
    },
  })

  await db.conversation.update({
    where: { id: String(conversationId) },
    data: { updatedAt: new Date() },
  })

  return NextResponse.json({
    message: {
      ...msg,
      senderId: msg.senderId,
      senderRole: me.role,
    },
  })
}

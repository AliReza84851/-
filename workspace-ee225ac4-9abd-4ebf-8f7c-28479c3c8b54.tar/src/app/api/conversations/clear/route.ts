import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'

// DELETE /api/conversations/clear?conversationId=...
// Removes all messages in the conversation (for the current user's view).
export async function DELETE(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me) return NextResponse.json({ error: 'ابتدا وارد شوید' }, { status: 401 })
  const url = new URL(req.url)
  const conversationId = url.searchParams.get('conversationId')
  if (!conversationId) return NextResponse.json({ error: 'conversationId الزامی' }, { status: 400 })

  const conv = await db.conversation.findUnique({ where: { id: conversationId } })
  if (!conv || (conv.doctorId !== me.userId && conv.patientId !== me.userId)) {
    return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 })
  }

  await db.message.deleteMany({ where: { conversationId } })
  await db.conversation.update({
    where: { id: conversationId },
    data: { updatedAt: new Date() },
  })

  return NextResponse.json({ ok: true, cleared: conversationId })
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'

// GET /api/conversations/list
// returns all conversations for the current user with last message preview + unread count
export async function GET(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me) return NextResponse.json({ error: 'ابتدا وارد شوید' }, { status: 401 })

  const where = me.role === 'DOCTOR' ? { doctorId: me.userId } : { patientId: me.userId }
  const convs = await db.conversation.findMany({
    where,
    include: {
      doctor: { select: { id: true, name: true, specialty: true } },
      patient: { select: { id: true, name: true, phone: true } },
      messages: {
        orderBy: { createdAt: 'desc' },
        take: 1,
      },
    },
    orderBy: { updatedAt: 'desc' },
  })

  // count unread
  const ids = convs.map((c) => c.id)
  const unreadCounts = await db.message.groupBy({
    by: ['conversationId'],
    where: {
      conversationId: { in: ids },
      senderId: { not: me.userId },
      isRead: false,
    },
    _count: { id: true },
  })
  const unreadMap = new Map(unreadCounts.map((u) => [u.conversationId, u._count.id]))

  return NextResponse.json({
    conversations: convs.map((c) => ({
      id: c.id,
      doctor: c.doctor,
      patient: c.patient,
      lastMessage: c.messages[0]?.content || null,
      lastMessageAt: c.messages[0]?.createdAt || c.updatedAt,
      unread: unreadMap.get(c.id) || 0,
    })),
  })
}

// POST /api/conversations/list - get-or-create a conversation between patient and doctor
export async function POST(req: NextRequest) {
  const me = await getCurrentUser(req)
  if (!me) return NextResponse.json({ error: 'ابتدا وارد شوید' }, { status: 401 })
  const body = await req.json()
  const { doctorId, patientId } = body || {}

  let docId = doctorId
  let patId = patientId

  if (me.role === 'PATIENT') {
    patId = me.userId
    if (!docId) return NextResponse.json({ error: 'doctorId الزامی است' }, { status: 400 })
  } else if (me.role === 'DOCTOR') {
    docId = me.userId
    if (!patId) return NextResponse.json({ error: 'patientId الزامی است' }, { status: 400 })
  } else {
    return NextResponse.json({ error: 'نقش نامعتبر' }, { status: 400 })
  }

  let conv = await db.conversation.findFirst({
    where: { doctorId: docId, patientId: patId },
    include: {
      doctor: { select: { id: true, name: true, specialty: true } },
      patient: { select: { id: true, name: true, phone: true } },
    },
  })
  if (!conv) {
    conv = await db.conversation.create({
      data: { doctorId: docId, patientId: patId },
      include: {
        doctor: { select: { id: true, name: true, specialty: true } },
        patient: { select: { id: true, name: true, phone: true } },
      },
    })
  }
  return NextResponse.json({ conversation: conv })
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/slots?doctorId=...&date=YYYY-MM-DD
// returns available 30-min slots based on working hours + existing appointments for that day-of-week
function pad(n: number) {
  return n < 10 ? '0' + n : '' + n
}
function timeToMin(t: string): number {
  const [h, m] = t.split(':').map(Number)
  return h * 60 + (m || 0)
}
function minToTime(min: number): string {
  return `${pad(Math.floor(min / 60))}:${pad(min % 60)}`
}

// Persian week order: 0=Sat,1=Sun,2=Mon,3=Tue,4=Wed,5=Thu,6=Fri
function dayOfWeekPersian(date: Date): number {
  const jsDay = date.getDay() // 0=Sun ... 6=Sat
  // map JS day to Persian order
  // JS: Sun(0),Mon(1),Tue(2),Wed(3),Thu(4),Fri(5),Sat(6)
  // Persian: Sat(0),Sun(1),Mon(2),Tue(3),Wed(4),Thu(5),Fri(6)
  const map: Record<number, number> = { 0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 0 }
  return map[jsDay]
}

export async function GET(req: NextRequest) {
  const url = new URL(req.url)
  const doctorId = url.searchParams.get('doctorId')
  const dateStr = url.searchParams.get('date') // YYYY-MM-DD
  if (!doctorId || !dateStr) {
    return NextResponse.json({ error: 'doctorId و date الزامی است' }, { status: 400 })
  }

  const date = new Date(dateStr + 'T00:00:00')
  const dow = dayOfWeekPersian(date)
  const hours = await db.workingHour.findMany({
    where: { doctorId, dayOfWeek: dow, isActive: true },
    orderBy: { startTime: 'asc' },
  })
  if (hours.length === 0) {
    return NextResponse.json({ slots: [], message: 'این روز تعطیل است' })
  }

  // existing appts for that date
  const appts = await db.appointment.findMany({
    where: { doctorId, date: dateStr, status: { in: ['PENDING', 'APPROVED'] } },
  })
  const taken = new Set(appts.map((a) => `${a.startTime}-${a.endTime}`))

  const slots: { startTime: string; endTime: string; available: boolean }[] = []
  const now = new Date()
  for (const h of hours) {
    const start = timeToMin(h.startTime)
    const end = timeToMin(h.endTime)
    const step = h.slotMinutes || 30
    for (let t = start; t + step <= end; t += step) {
      const s = minToTime(t)
      const e = minToTime(t + step)
      const isToday = dateStr === now.toISOString().slice(0, 10)
      const nowMin = now.getHours() * 60 + now.getMinutes()
      const past = isToday && t <= nowMin
      slots.push({
        startTime: s,
        endTime: e,
        available: !taken.has(`${s}-${e}`) && !past,
      })
    }
  }
  return NextResponse.json({ slots, workingHours: hours, dayOfWeek: dow })
}

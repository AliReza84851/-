import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "مطب دندان‌پزشکی | سامانه نوبت‌دهی آنلاین",
  description: "سامانه هوشمند نوبت‌دهی آنلاین مطب دندان‌پزشکی با چت زنده، مدیریت ساعات کاری و تایید نوبت توسط پزشک.",
  keywords: ["نوبت", "دندان‌پزشکی", "مطب", "رزرو آنلاین", "چت پزشک"],
  authors: [{ name: "Dental Clinic" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster position="top-center" richColors closeButton />
      </body>
    </html>
  );
}

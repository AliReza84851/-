'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion'
import { useApp, api } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Calendar,
  Clock,
  Stethoscope,
  MessageCircle,
  CalendarClock,
  LogOut,
  Smile,
  Sparkles,
  ArrowLeft,
  ShieldCheck,
  HeartPulse,
  LogIn,
} from 'lucide-react'
import AuthDialog from '@/components/auth/AuthDialog'
import BookingForm from '@/components/patient/BookingForm'
import PatientAppointments from '@/components/patient/PatientAppointments'
import DoctorAppointments from '@/components/doctor/DoctorAppointments'
import HomeDashboard from '@/components/shared/HomeDashboard'
import WorkingHoursManager from '@/components/doctor/WorkingHoursManager'
import ChatPanel from '@/components/chat/ChatPanel'
import ConversationList from '@/components/chat/ConversationList'
import { toast } from 'sonner'
import { toPersianDigits } from '@/lib/persian'
import { EASE, containerVariants, itemVariants, pageTransition } from '@/lib/motion'

// Stagger container variants (kept for backward compat)
const _containerVariants = containerVariants
const _itemVariants = itemVariants

export default function Home() {
  const { token, user, view, setView, clearAuth, activeConversationId, setActiveConversationId } = useApp()
  const [authOpen, setAuthOpen] = useState(false)
  const [convRefreshKey, setConvRefreshKey] = useState(0)

  // refresh me on mount
  useEffect(() => {
    if (token) {
      api<{ user: any }>('/api/auth/me', {}, token)
        .then((r) => {
          if (!r.user) {
            clearAuth()
          }
        })
        .catch(() => clearAuth())
    }
  }, [])

  const logout = async () => {
    if (token) await api('/api/auth/logout', { method: 'POST' }, token).catch(() => null)
    clearAuth()
    setActiveConversationId(null)
    toast.success('با موفقیت خارج شدید')
  }

  // nav items based on role
  const navItems: { view: any; label: string; icon: any }[] = user
    ? user.role === 'PATIENT'
      ? [
          { view: 'home', label: 'خانه', icon: Smile },
          { view: 'book', label: 'رزرو نوبت', icon: Calendar },
          { view: 'my-appointments', label: 'نوبت‌های من', icon: CalendarClock },
          { view: 'chat', label: 'چت با پزشک', icon: MessageCircle },
        ]
      : [
          { view: 'home', label: 'خانه', icon: Smile },
          { view: 'manage-appointments', label: 'نوبت‌ها', icon: Calendar },
          { view: 'working-hours', label: 'ساعات کاری', icon: Clock },
          { view: 'chat', label: 'چت با بیماران', icon: MessageCircle },
        ]
    : []

  const renderContent = () => {
    if (!user) {
      // landing page
      return <Landing onAuth={() => setAuthOpen(true)} />
    }
    switch (view) {
      case 'home':
        return <HomeDashboard />
      case 'book':
        return <BookingForm />
      case 'my-appointments':
        return <PatientAppointments />
      case 'manage-appointments':
        return <DoctorAppointments />
      case 'working-hours':
        return <WorkingHoursManager />
      case 'chat':
        return (
          <div className="grid lg:grid-cols-3 gap-4 lg:h-[72vh]">
            {/* On mobile: show list OR chat panel; on desktop: show both side-by-side */}
            <div className={`lg:col-span-1 ${activeConversationId ? 'hidden lg:block' : 'block'}`}>
              <ConversationList
                onSelect={(id) => {
                  setActiveConversationId(id)
                  setConvRefreshKey((k) => k + 1)
                }}
                selectedId={activeConversationId}
                refreshKey={convRefreshKey}
              />
            </div>
            <div className={`lg:col-span-2 ${activeConversationId ? 'block' : 'hidden lg:block'}`}>
              <ChatPanel
                conversationId={activeConversationId}
                onBack={() => setActiveConversationId(null)}
              />
            </div>
          </div>
        )
      default:
        if (user.role === 'PATIENT') return <BookingForm />
        return <DoctorAppointments />
    }
  }

  return (
    <div dir="rtl" className="min-h-screen flex flex-col bg-gradient-to-b from-teal-50/40 via-white to-white">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-lg sticky top-0 z-30">
        <div className="container mx-auto max-w-6xl px-4 h-16 flex items-center justify-between gap-3">
          {/* Logo */}
          <motion.button
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, ease: EASE }}
            onClick={() => setView('home')}
            className="flex items-center gap-2 group"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <div className="size-9 rounded-xl bg-gradient-to-br from-teal-500 to-teal-700 text-white grid place-items-center shadow-md shadow-teal-600/20 group-hover:shadow-lg group-hover:shadow-teal-600/30 transition-shadow">
              <Smile className="size-5" />
            </div>
            <div className="text-right">
              <div className="font-bold leading-tight">مطب دندان‌پزشکی</div>
              <div className="text-[10px] text-muted-foreground">سامانه نوبت‌دهی آنلاین</div>
            </div>
          </motion.button>

          {/* Desktop nav */}
          {user && (
            <nav className="hidden md:flex items-center gap-1 bg-muted/40 rounded-full p-1">
              {navItems.map((n) => {
                const Icon = n.icon
                const active = view === n.view
                return (
                  <button
                    key={n.view}
                    onClick={() => setView(n.view)}
                    className={`relative px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                      active ? 'text-white' : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    {active && (
                      <motion.span
                        layoutId="nav-active-pill"
                        className="absolute inset-0 rounded-full bg-gradient-to-l from-teal-600 to-emerald-600 shadow-md shadow-teal-600/30"
                        transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                      />
                    )}
                    <span className="relative z-10 flex items-center gap-1.5">
                      <Icon className="size-4" />
                      {n.label}
                    </span>
                  </button>
                )
              })}
            </nav>
          )}

          {/* Right side */}
          <div className="flex items-center gap-2">
            {user ? (
              <>
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4 }}
                  className="hidden sm:block text-right"
                >
                  <div className="text-sm font-medium leading-tight">{user.name}</div>
                  <div className="text-[10px] text-muted-foreground">
                    {user.role === 'DOCTOR' ? 'پزشک' : 'بیمار'}
                    {user.role === 'DOCTOR' && user.specialty ? ` · ${user.specialty}` : ''}
                  </div>
                </motion.div>
                <Button variant="outline" size="sm" onClick={logout} aria-label="خروج" className="size-9 p-0">
                  <LogOut className="size-4" />
                </Button>
              </>
            ) : (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, ease: EASE }}
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.97 }}
              >
                <Button onClick={() => setAuthOpen(true)} className="bg-teal-600 hover:bg-teal-700 shadow-md shadow-teal-600/20 text-sm">
                  <LogIn className="size-4 ml-2" />
                  <span className="hidden xs:inline sm:inline">ورود / ثبت‌نام</span>
                  <span className="xs:hidden sm:hidden">ورود</span>
                </Button>
              </motion.div>
            )}
          </div>
        </div>
      </header>

      {/* Main content with animated page transitions */}
      <main className="container mx-auto max-w-6xl px-3 sm:px-4 py-4 sm:py-6 flex-1 pb-20 md:pb-6">
        <AnimatePresence mode="wait">
          <motion.div key={view || 'landing'} {...pageTransition}>
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Mobile bottom navigation */}
      {user && (
        <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white border-t shadow-[0_-2px_8px_rgba(0,0,0,0.04)]">
          <div className="grid grid-cols-5 gap-1 px-1 py-1.5" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
            {navItems.map((n) => {
              const Icon = n.icon
              const active = view === n.view
              return (
                <button
                  key={n.view}
                  onClick={() => setView(n.view)}
                  className="relative flex flex-col items-center justify-center gap-0.5 py-1.5 rounded-lg text-[10px] transition"
                >
                  {active && (
                    <motion.span
                      layoutId="mobile-nav-active"
                      className="absolute inset-0 rounded-lg bg-teal-50"
                      transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                    />
                  )}
                  <Icon className={`relative z-10 size-5 transition-colors ${active ? 'text-teal-600' : 'text-muted-foreground'}`} />
                  <span className={`relative z-10 leading-tight transition-colors ${active ? 'text-teal-600 font-medium' : 'text-muted-foreground'}`}>{n.label}</span>
                </button>
              )
            })}
            {/* Logout button */}
            <button
              onClick={logout}
              className="flex flex-col items-center justify-center gap-0.5 py-1.5 rounded-md text-[10px] text-rose-500"
            >
              <LogOut className="size-5" />
              <span className="leading-tight">خروج</span>
            </button>
          </div>
        </nav>
      )}

      <AuthDialog open={authOpen} onOpenChange={setAuthOpen} />
    </div>
  )
}

function Landing({ onAuth }: { onAuth: () => void }) {
  const reduce = useReducedMotion()

  return (
    <div className="space-y-12 relative">
      {/* Background decorative blobs */}
      <div className="absolute inset-0 -z-10 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-10 -right-20 size-72 rounded-full bg-teal-200/40 blur-3xl"
          animate={reduce ? {} : { y: [0, -20, 0], x: [0, 10, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute top-40 -left-20 size-96 rounded-full bg-emerald-200/30 blur-3xl"
          animate={reduce ? {} : { y: [0, 30, 0], x: [0, -15, 0] }}
          transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
        />
        <motion.div
          className="absolute bottom-20 right-1/4 size-80 rounded-full bg-cyan-200/30 blur-3xl"
          animate={reduce ? {} : { y: [0, -25, 0] }}
          transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
        />
      </div>

      {/* Hero + TOP login section */}
      <motion.section
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="text-center pt-10 pb-4 relative"
      >
        <motion.div variants={itemVariants}>
          <Badge className="mb-5 bg-gradient-to-l from-teal-100 to-emerald-100 text-teal-800 hover:bg-teal-100 inline-flex items-center gap-1 border-teal-200/50 shadow-sm">
            <Sparkles className="size-3.5" /> سامانه هوشمند نوبت‌دهی
          </Badge>
        </motion.div>
        <motion.h1
          variants={itemVariants}
          className="text-4xl md:text-6xl font-bold tracking-tight bg-gradient-to-b from-teal-700 via-teal-600 to-emerald-600 bg-clip-text text-transparent leading-tight"
        >
          نوبت‌دهی آنلاین
          <br />
          مطب دندان‌پزشکی
        </motion.h1>
        <motion.p variants={itemVariants} className="mt-5 text-muted-foreground max-w-2xl mx-auto text-base md:text-lg leading-relaxed">
          بدون معطلی و در چند ثانیه نوبت خود را رزرو کنید. ساعات کاری پزشک را ببینید،
          تایم دلخواهتان را انتخاب کنید و قبل از مراجعه با پزشک چت کنید.
        </motion.p>

        {/* Stats strip */}
        <motion.div variants={itemVariants} className="mt-6 flex items-center justify-center gap-6 sm:gap-10 flex-wrap">
          {[
            { v: '+۱۰۰۰', l: 'نوبت ثبت‌شده' },
            { v: '۲۴/۷', l: 'در دسترس' },
            { v: '+۵۰', l: 'پزشک فعال' },
          ].map((s) => (
            <div key={s.l} className="text-center">
              <div className="text-xl sm:text-2xl font-bold bg-gradient-to-l from-teal-600 to-emerald-600 bg-clip-text text-transparent">{s.v}</div>
              <div className="text-[10px] sm:text-xs text-muted-foreground mt-0.5">{s.l}</div>
            </div>
          ))}
        </motion.div>

        {/* TOP login section: two prominent cards */}
        <motion.div
          variants={itemVariants}
          className="mt-8 grid sm:grid-cols-2 gap-4 max-w-2xl mx-auto"
        >
          <LoginCard
            tone="teal"
            icon={<HeartPulse className="size-6" />}
            badge="برای بیماران"
            title="ورود بیماران"
            desc="نوبت‌دهی، مشاهده تاریخچه و چت با پزشک"
            ctaLabel="ورود / ثبت‌نام"
            onAuth={onAuth}
          />
          <LoginCard
            tone="emerald"
            icon={<Stethoscope className="size-6" />}
            badge="برای پزشکان"
            title="ورود پزشکان"
            desc="مدیریت نوبت‌ها، تنظیم ساعات کاری و چت با بیماران"
            ctaLabel="پنل پزشک"
            onAuth={onAuth}
          />
        </motion.div>
      </motion.section>

      {/* Features */}
      <motion.section
        variants={containerVariants}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.2 }}
        className="grid md:grid-cols-3 gap-4"
      >
        {[
          {
            icon: Calendar,
            title: 'رزرو سریع نوبت',
            desc: 'با دیدن ساعات کاری پزشک، تایم مناسب خود را انتخاب کنید و در لحظه ثبت کنید.',
          },
          {
            icon: Clock,
            title: 'ساعات کاری شفاف',
            desc: 'پزشک ساعات کاری هفتگی خود را تنظیم می‌کند و بیماران تایم‌های خالی را به‌سادگی می‌بینند.',
          },
          {
            icon: MessageCircle,
            title: 'چت مستقیم با پزشک',
            desc: 'پس از رزرو نوبت، می‌توانید مستقیماً با پزشک چت کنید و سوال‌هایتان را بپرسید.',
          },
          {
            icon: Stethoscope,
            title: 'پنل مدیریت پزشک',
            desc: 'پزشک نوبت‌ها را تایید، رد یا در انتظار نگه می‌دارد و یادداشت برای هر بیمار ثبت می‌کند.',
          },
          {
            icon: Smile,
            title: 'تجربه کاربری ساده',
            desc: 'رابط کاربری فارسی و راست‌چین، سازگار با موبایل و دسکتاپ.',
          },
          {
            icon: ShieldCheck,
            title: 'امنیت و حریم خصوصی',
            desc: 'تمام ارتباطات و نوبت‌ها در یک سامانه امن، بدون نیاز به تماس تلفنی.',
          },
        ].map((f, i) => {
          const Icon = f.icon
          return (
            <motion.div
              key={i}
              variants={itemVariants}
              whileHover={{ y: -8, scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300, damping: 20 }}
              className="border rounded-2xl p-5 bg-white shadow-sm hover:shadow-xl hover:shadow-teal-600/10 transition-shadow relative overflow-hidden group"
            >
              {/* decorative hover glow */}
              <div className="absolute inset-0 -z-10 bg-gradient-to-br from-teal-50/0 via-teal-50/0 to-emerald-50/0 group-hover:from-teal-50/70 group-hover:to-emerald-50/50 transition-all duration-500" />
              {/* animated corner accent */}
              <motion.div
                className="absolute -top-6 -left-6 size-16 rounded-full bg-gradient-to-br from-teal-200/40 to-emerald-200/30 blur-xl opacity-0 group-hover:opacity-100"
                animate={reduce ? {} : { rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
              />
              <motion.div
                whileHover={{ rotate: 8, scale: 1.1 }}
                transition={{ type: 'spring', stiffness: 400, damping: 12 }}
                className="size-12 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white grid place-items-center mb-3 shadow-md shadow-teal-600/20"
              >
                <Icon className="size-6" />
              </motion.div>
              <h3 className="font-semibold mb-1">{f.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </motion.div>
          )
        })}
      </motion.section>

      {/* How it works */}
      <motion.section
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.6, ease: EASE }}
        className="border rounded-2xl p-6 md:p-8 bg-white relative overflow-hidden"
      >
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-teal-50/40 to-transparent" />
        <motion.h2
          className="text-2xl md:text-3xl font-bold mb-6 text-center bg-gradient-to-b from-teal-700 to-emerald-700 bg-clip-text text-transparent"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          چطور کار می‌کند؟
        </motion.h2>
        <div className="grid md:grid-cols-4 gap-4">
          {[
            { n: 1, t: 'ثبت‌نام کنید', d: 'به‌عنوان بیمار یا پزشک در سامانه عضو شوید.' },
            { n: 2, t: 'روز و تایم انتخاب کنید', d: 'ساعات کاری پزشک را ببینید و تایم خالی انتخاب کنید.' },
            { n: 3, t: 'منتظر تایید بمانید', d: 'پزشک در پنل خود نوبت شما را تایید یا رد می‌کند.' },
            { n: 4, t: 'چت و مراجعه', d: 'با پزشک چت کنید و در زمان مقرر به مطب مراجعه کنید.' },
          ].map((s, i) => (
            <motion.div
              key={s.n}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.12, ease: EASE }}
              className="relative text-center md:text-right"
            >
              <div className="flex md:block items-center gap-3 mb-2">
                <motion.div
                  whileHover={{ scale: 1.15, rotate: 5 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 15 }}
                  className="size-10 rounded-full bg-gradient-to-br from-teal-500 to-emerald-600 text-white grid place-items-center font-bold shadow-md shadow-teal-600/30 shrink-0"
                >
                  {toPersianDigits(s.n)}
                </motion.div>
                <h4 className="font-medium text-sm">{s.t}</h4>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">{s.d}</p>
              {/* connecting arrow (desktop only) */}
              {i < 3 && (
                <ArrowLeft className="hidden md:block absolute top-3 -left-3 size-4 text-teal-300" />
              )}
            </motion.div>
          ))}
        </div>
      </motion.section>
    </div>
  )
}

// Reusable login card (used in the TOP section)
function LoginCard({
  tone,
  icon,
  badge,
  title,
  desc,
  ctaLabel,
  onAuth,
}: {
  tone: 'teal' | 'emerald'
  icon: React.ReactNode
  badge: string
  title: string
  desc: string
  ctaLabel: string
  onAuth: () => void
}) {
  const reduce = useReducedMotion()
  const grad =
    tone === 'teal'
      ? 'from-teal-500 to-teal-700'
      : 'from-emerald-500 to-emerald-700'
  const softBg = tone === 'teal' ? 'bg-teal-50' : 'bg-emerald-50'
  const iconColor = tone === 'teal' ? 'text-teal-700' : 'text-emerald-700'

  return (
    <motion.div
      whileHover={reduce ? {} : { y: -8 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className="border-2 border-teal-100 rounded-2xl bg-white p-6 text-right shadow-md hover:shadow-2xl hover:shadow-teal-600/15 transition-all relative overflow-hidden group"
    >
      <div className={`absolute -top-12 -left-12 size-40 rounded-full ${softBg} blur-3xl opacity-60 group-hover:opacity-100 transition-opacity duration-500`} />
      {/* shimmer line on hover */}
      <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-l from-transparent via-teal-400 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-3">
          <motion.div
            whileHover={reduce ? {} : { rotate: 12, scale: 1.1 }}
            transition={{ type: 'spring', stiffness: 400, damping: 12 }}
            className={`size-14 rounded-2xl bg-gradient-to-br ${grad} text-white grid place-items-center shadow-lg shadow-teal-600/20`}
          >
            {icon}
          </motion.div>
          <Badge variant="outline" className="bg-white/80 backdrop-blur">
            {badge}
          </Badge>
        </div>
        <h3 className="text-lg font-bold mb-1">{title}</h3>
        <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{desc}</p>
        <Button
          onClick={onAuth}
          className={`w-full bg-gradient-to-l ${grad} hover:opacity-90 text-white shadow-md group-hover:shadow-lg transition-all`}
        >
          <LogIn className="size-4 ml-2 group-hover:translate-x-0.5 transition-transform" />
          {ctaLabel}
        </Button>
      </div>
    </motion.div>
  )
}

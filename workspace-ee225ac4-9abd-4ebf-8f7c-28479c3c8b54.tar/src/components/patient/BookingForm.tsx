'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion'
import { useApp, api } from '@/lib/store'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { getNextDays, PERSIAN_DAYS, toPersianDigits } from '@/lib/persian'
import {
  Check,
  Loader2,
  Stethoscope,
  Calendar,
  Clock,
  ClipboardList,
  Sparkles,
} from 'lucide-react'
import { toast } from 'sonner'
import { EASE, containerVariants, itemVariants } from '@/lib/motion'

interface Doctor {
  id: string
  name: string
  specialty?: string | null
  phone: string
  email?: string | null
  hasHours: boolean
}

interface Slot {
  startTime: string
  endTime: string
  available: boolean
}

interface WorkingHour {
  id: string
  dayOfWeek: number
  startTime: string
  endTime: string
  slotMinutes: number
  isActive: boolean
}

const PERSIAN_WEEKDAYS_SHORT = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج']

export default function BookingForm() {
  const { token, user, setView, setActiveConversationId } = useApp()
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [doctorId, setDoctorId] = useState<string>('')
  const [doctorHours, setDoctorHours] = useState<WorkingHour[]>([])
  const [days] = useState(() => getNextDays(14))
  const [selectedDay, setSelectedDay] = useState<string>(days[0]?.greg || '')
  const [slots, setSlots] = useState<Slot[]>([])
  const [selectedSlot, setSelectedSlot] = useState<Slot | null>(null)
  const [reason, setReason] = useState('')
  const [loadingDoctors, setLoadingDoctors] = useState(true)
  const [loadingSlots, setLoadingSlots] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    api<{ doctors: Doctor[] }>('/api/doctors')
      .then((r) => {
        setDoctors(r.doctors)
        if (r.doctors[0]) setDoctorId(r.doctors[0].id)
      })
      .finally(() => setLoadingDoctors(false))
  }, [])

  useEffect(() => {
    if (!doctorId) return
    api<{ workingHours: WorkingHour[] }>(`/api/working-hours?doctorId=${doctorId}`)
      .then((r) => setDoctorHours(r.workingHours))
      .catch(() => setDoctorHours([]))
  }, [doctorId])

  useEffect(() => {
    if (!doctorId || !selectedDay) return
    setLoadingSlots(true)
    setSelectedSlot(null)
    api<{ slots: Slot[]; message?: string }>(
      `/api/slots?doctorId=${doctorId}&date=${selectedDay}`
    )
      .then((r) => setSlots(r.slots))
      .catch(() => setSlots([]))
      .finally(() => setLoadingSlots(false))
  }, [doctorId, selectedDay])

  const handleSubmit = async () => {
    if (!token || !user) {
      toast.error('ابتدا وارد شوید')
      return
    }
    if (!doctorId || !selectedSlot || !selectedDay) {
      toast.error('لطفاً پزشک، روز و تایم را انتخاب کنید')
      return
    }
    setSubmitting(true)
    try {
      await api<{ appointment: any }>(
        '/api/appointments',
        {
          method: 'POST',
          body: JSON.stringify({
            doctorId,
            date: selectedDay,
            startTime: selectedSlot.startTime,
            endTime: selectedSlot.endTime,
            reason: reason.trim(),
          }),
        },
        token
      )
      const conv = await api<{ conversation: any }>(
        '/api/conversations/list',
        {
          method: 'POST',
          body: JSON.stringify({ doctorId }),
        },
        token
      )
      setActiveConversationId(conv.conversation.id)
      toast.success(`نوبت شما با موفقیت ثبت شد. لطفاً منتظر تایید پزشک بمانید.`)
      setView('my-appointments')
    } catch (e: any) {
      toast.error(e.message || 'ثبت نوبت ناموفق بود')
    } finally {
      setSubmitting(false)
    }
  }

  const selectedDoctor = doctors.find((d) => d.id === doctorId)
  const selectedDayObj = days.find((d) => d.greg === selectedDay)

  const stepComplete = (n: number) => {
    if (n === 1) return !!doctorId
    if (n === 2) return !!selectedDay
    if (n === 3) return !!selectedSlot
    return false
  }

  return (
    <div className="space-y-5">
      {/* Header banner */}
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="rounded-2xl bg-gradient-to-l from-teal-600 via-teal-500 to-emerald-500 p-5 text-white shadow-lg shadow-teal-600/20 relative overflow-hidden"
      >
        <motion.div
          className="absolute -top-8 -left-8 size-32 rounded-full bg-white/15 blur-2xl"
          animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute -bottom-12 -right-4 size-28 rounded-full bg-emerald-200/20 blur-2xl"
          animate={{ scale: [1, 1.15, 1], opacity: [0.2, 0.5, 0.2] }}
          transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
        />
        <div className="relative z-10 flex items-center gap-3">
          <motion.div
            initial={{ rotate: -180, scale: 0 }}
            animate={{ rotate: 0, scale: 1 }}
            transition={{ type: 'spring', stiffness: 260, damping: 18, delay: 0.2 }}
            className="size-11 rounded-xl bg-white/20 backdrop-blur grid place-items-center shrink-0"
          >
            <Calendar className="size-6" />
          </motion.div>
          <div>
            <h2 className="text-lg font-bold leading-tight">رزرو نوبت آنلاین</h2>
            <p className="text-sm text-white/80 mt-0.5">
              در سه مرحله ساده نوبت خود را ثبت کنید
            </p>
          </div>
        </div>
      </motion.div>

      {/* Stepper indicator */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.4 }}
        className="flex items-center gap-1 sm:gap-2 px-1"
      >
        {[
          { n: 1, label: 'پزشک', icon: Stethoscope },
          { n: 2, label: 'روز', icon: Calendar },
          { n: 3, label: 'تایم', icon: Clock },
        ].map((s, i) => {
          const done = stepComplete(s.n)
          const active = !done && (i === 0 || stepComplete(s.n - 1))
          const Icon = s.icon
          return (
            <div key={s.n} className="flex items-center flex-1">
              <motion.div
                animate={{ scale: done ? [1, 1.1, 1] : 1 }}
                transition={{ duration: 0.3 }}
                className={`flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium transition-all ${
                  done
                    ? 'bg-teal-600 text-white shadow-sm shadow-teal-600/30'
                    : active
                    ? 'bg-teal-50 text-teal-700 border border-teal-200'
                    : 'bg-muted/50 text-muted-foreground'
                }`}
              >
                <span
                  className={`size-5 rounded-full grid place-items-center text-[10px] ${
                    done ? 'bg-white/20' : active ? 'bg-teal-600 text-white' : 'bg-muted'
                  }`}
                >
                  {done ? <Check className="size-3" /> : <Icon className="size-3" />}
                </span>
                <span className="hidden sm:inline">{s.label}</span>
              </motion.div>
              {i < 2 && (
                <motion.div
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ delay: 0.3 + i * 0.1, duration: 0.4 }}
                  className={`h-0.5 flex-1 mx-1 rounded-full origin-right ${
                    done ? 'bg-teal-500' : 'bg-muted'
                  }`}
                />
              )}
            </div>
          )
        })}
      </motion.div>

      <div className="grid lg:grid-cols-12 gap-5 lg:items-start">
        {/* Step 1: doctor selection */}
        <Card className="lg:col-span-4 border-teal-100 shadow-sm overflow-hidden">
          <div className="bg-gradient-to-l from-teal-50 to-emerald-50/50 px-4 py-3 border-b border-teal-100/70 flex items-center gap-2">
            <div className="size-7 rounded-lg bg-teal-600 text-white grid place-items-center text-xs font-bold">
              ۱
            </div>
            <div className="flex-1">
              <div className="text-sm font-bold text-teal-900">انتخاب پزشک</div>
              <div className="text-[11px] text-muted-foreground">یکی از پزشکان مطب</div>
            </div>
          </div>
          <CardContent className="p-3 space-y-2">
            {loadingDoctors && (
              <div className="flex items-center gap-2 text-muted-foreground text-sm py-6 justify-center">
                <Loader2 className="size-4 animate-spin" /> بارگذاری…
              </div>
            )}
            {!loadingDoctors && doctors.length === 0 && (
              <div className="text-sm text-muted-foreground py-6 text-center">
                پزشکی یافت نشد
              </div>
            )}
            <AnimatePresence>
              {doctors.map((d, idx) => {
                const selected = doctorId === d.id
                return (
                  <motion.button
                    key={d.id}
                    initial={{ opacity: 0, x: 16 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.08, duration: 0.3 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setDoctorId(d.id)}
                    className={`w-full text-right p-3 rounded-xl border-2 transition-all flex items-center gap-3 ${
                      selected
                        ? 'border-teal-500 bg-teal-50/80 shadow-sm shadow-teal-500/10'
                        : 'border-transparent bg-muted/30 hover:bg-muted/60 hover:border-teal-200'
                    }`}
                  >
                  <div
                    className={`size-11 rounded-xl grid place-items-center shrink-0 transition-colors ${
                      selected
                        ? 'bg-gradient-to-br from-teal-500 to-emerald-500 text-white'
                        : 'bg-teal-100 text-teal-700'
                    }`}
                  >
                    <Stethoscope className="size-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-sm truncate">{d.name}</div>
                    <div className="text-xs text-muted-foreground truncate">
                      {d.specialty || 'دندان‌پزشک'}
                    </div>
                    {!d.hasHours && (
                      <Badge variant="outline" className="mt-1 text-[10px] text-rose-600 px-1.5 py-0">
                        بدون ساعات کاری
                      </Badge>
                    )}
                  </div>
                  {selected && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', stiffness: 500, damping: 20 }}
                      className="size-6 rounded-full bg-teal-600 text-white grid place-items-center shrink-0"
                    >
                      <Check className="size-3.5" />
                    </motion.div>
                  )}
                </motion.button>
              )
            })}
            </AnimatePresence>
          </CardContent>
        </Card>

        {/* Step 2 + 3: day and slot selection */}
        <Card className="lg:col-span-8 border-teal-100 shadow-sm overflow-hidden">
          <div className="bg-gradient-to-l from-teal-50 to-emerald-50/50 px-4 py-2 border-b border-teal-100/70 flex items-center gap-2">
            <div className="size-6 rounded-md bg-teal-600 text-white grid place-items-center text-xs font-bold">
              ۲
            </div>
            <div className="flex-1">
              <div className="text-sm font-bold text-teal-900">انتخاب روز و تایم</div>
              <div className="text-[11px] text-muted-foreground">
                {selectedDoctor ? selectedDoctor.name : 'ابتدا پزشک را انتخاب کنید'}
              </div>
            </div>
            {doctorHours.length > 0 && (
              <Badge variant="outline" className="bg-white/70 text-teal-700 border-teal-200 text-[10px] gap-1">
                <Clock className="size-3" />
                {doctorHours.filter((h) => h.isActive).length} شیفت
              </Badge>
            )}
          </div>

          <CardContent className="p-3">
            {/* Day + Slots side by side */}
            <div className="grid sm:grid-cols-2 gap-3">
              {/* Day selector — compact date cards */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <Label className="text-xs font-semibold text-muted-foreground flex items-center gap-1">
                    <Calendar className="size-3" /> روز مراجعه
                  </Label>
                  {selectedDayObj && (
                    <span className="text-[10px] text-teal-700 font-medium truncate max-w-[100px]">
                      {selectedDayObj.label.split('-')[1]?.trim()}
                    </span>
                  )}
                </div>
                <div className="grid grid-cols-7 gap-1">
                  {days.map((d, idx) => {
                    const sel = selectedDay === d.greg
                    const [, monthStr, dayStr] = d.jalaliISO.split('-')
                    const dayNum = parseInt(dayStr, 10)
                    const weekdayShort = PERSIAN_WEEKDAYS_SHORT[idx % 7]
                    const isToday = idx === 0
                    return (
                      <motion.button
                        key={d.greg}
                        whileTap={{ scale: 0.92 }}
                        onClick={() => setSelectedDay(d.greg)}
                        className={`relative flex flex-col items-center justify-center py-1.5 rounded-lg border transition-all ${
                          sel
                            ? 'border-teal-500 bg-gradient-to-b from-teal-500 to-teal-600 text-white shadow-sm shadow-teal-500/25'
                            : 'border-transparent bg-muted/40 hover:bg-muted/70'
                        }`}
                      >
                        {isToday && (
                          <span className={`absolute top-0.5 right-0.5 size-1 rounded-full ${sel ? 'bg-white' : 'bg-teal-500'}`} />
                        )}
                        <span className={`text-[9px] ${sel ? 'text-white/80' : 'text-muted-foreground'}`}>
                          {weekdayShort}
                        </span>
                        <span className={`text-sm font-bold leading-none mt-0.5 ${sel ? 'text-white' : 'text-foreground'}`}>
                          {toPersianDigits(dayNum)}
                        </span>
                      </motion.button>
                    )
                  })}
                </div>
              </div>

              {/* Slots — compact grid */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <Label className="text-xs font-semibold text-muted-foreground flex items-center gap-1">
                    <Clock className="size-3" /> تایم‌های خالی
                  </Label>
                  {slots.length > 0 && !loadingSlots && (
                    <span className="text-[10px] text-muted-foreground">
                      {toPersianDigits(slots.filter((s) => s.available).length)} آزاد
                    </span>
                  )}
                </div>
                {loadingSlots && (
                  <div className="flex items-center gap-2 text-muted-foreground text-xs py-4 justify-center">
                    <Loader2 className="size-3.5 animate-spin" /> بارگذاری…
                  </div>
                )}
                {!loadingSlots && slots.length === 0 && (
                  <div className="rounded-lg border border-dashed border-muted-foreground/30 py-4 text-center">
                    <Clock className="size-5 text-muted-foreground/40 mx-auto mb-1" />
                    <div className="text-xs text-muted-foreground">تایمی برای این روز نیست</div>
                  </div>
                )}
                {!loadingSlots && slots.length > 0 && (
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-1">
                    {slots.map((s, idx) => {
                      const sel = selectedSlot?.startTime === s.startTime
                      return (
                        <motion.button
                          key={s.startTime + s.endTime}
                          initial={{ opacity: 0, scale: 0.85 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: idx * 0.02, duration: 0.2 }}
                          whileTap={{ scale: 0.9 }}
                          whileHover={s.available ? { scale: 1.05 } : {}}
                          disabled={!s.available}
                          onClick={() => setSelectedSlot(s)}
                          className={`py-1.5 rounded-md border text-[11px] font-medium transition-all ${
                            !s.available
                              ? 'opacity-40 cursor-not-allowed bg-muted/30 border-muted text-muted-foreground line-through'
                              : sel
                              ? 'bg-gradient-to-b from-teal-500 to-teal-600 text-white border-teal-500 shadow-sm shadow-teal-500/25'
                              : 'border-muted-foreground/20 bg-white hover:border-teal-400 hover:bg-teal-50/50 text-foreground'
                          }`}
                        >
                          {toPersianDigits(s.startTime)}
                        </motion.button>
                      )
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Reason + submit — side by side */}
            <div className="mt-3 grid sm:grid-cols-5 gap-3">
              <div className="sm:col-span-3">
                <Label htmlFor="reason" className="text-xs font-semibold text-muted-foreground flex items-center gap-1 mb-1">
                  <ClipboardList className="size-3" /> علت مراجعه (اختیاری)
                </Label>
                <Input
                  id="reason"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="مثلاً: درد دندان، جرم‌گیری…"
                  className="text-sm"
                />
              </div>
              <div className="sm:col-span-2 flex items-end">
                <Button
                  onClick={handleSubmit}
                  disabled={submitting || !selectedSlot}
                  size="lg"
                  className="w-full bg-gradient-to-l from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white shadow-lg shadow-teal-600/25 rounded-xl h-11 text-sm font-bold"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="size-4 animate-spin ml-2" /> در حال ثبت…
                    </>
                  ) : (
                    <>
                      <Check className="size-4 ml-2" /> ثبت نوبت
                      {selectedSlot && (
                        <span className="mr-1 opacity-90">
                          ({toPersianDigits(selectedSlot.startTime)})
                        </span>
                      )}
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Working hours summary — compact chips */}
      {doctorHours.length > 0 && (
        <div className="rounded-xl border border-muted-foreground/10 bg-white p-3">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="size-4 text-teal-600" />
            <span className="text-xs font-bold text-muted-foreground">ساعات کاری پزشک</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {PERSIAN_DAYS.map((day, i) => {
              const hours = doctorHours.filter((h) => h.dayOfWeek === i && h.isActive)
              if (hours.length === 0) return null
              return (
                <div
                  key={i}
                  className="flex items-center gap-1.5 rounded-lg bg-teal-50/70 border border-teal-100 px-2.5 py-1 text-xs"
                >
                  <span className="font-semibold text-teal-800">{day}</span>
                  <span className="text-muted-foreground">
                    {hours.map((h) => `${toPersianDigits(h.startTime)}-${toPersianDigits(h.endTime)}`).join('، ')}
                  </span>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}

'use client'

import { useCallback, useEffect, useState } from 'react'
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion'
import { useApp, api } from '@/lib/store'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Calendar, Clock, MessageCircle, Loader2, RefreshCw, CalendarPlus, Stethoscope, StickyNote } from 'lucide-react'
import { toast } from 'sonner'
import { toJalali, toPersianDigits } from '@/lib/persian'
import { EASE, containerVariants, itemVariants } from '@/lib/motion'

interface Appt {
  id: string
  date: string
  startTime: string
  endTime: string
  reason?: string
  status: string
  note?: string | null
  doctor: { id: string; name: string; specialty?: string | null }
  patient: { id: string; name: string; phone: string }
}

const STATUS_LABEL: Record<string, string> = {
  PENDING: 'در انتظار',
  APPROVED: 'تایید شده',
  REJECTED: 'رد شده',
  COMPLETED: 'تکمیل شده',
  CANCELLED: 'لغو شده',
}
const STATUS_STYLE: Record<string, { badge: string; dot: string; ring: string }> = {
  PENDING: { badge: 'bg-amber-100 text-amber-800', dot: 'bg-amber-500', ring: 'ring-amber-200' },
  APPROVED: { badge: 'bg-emerald-100 text-emerald-800', dot: 'bg-emerald-500', ring: 'ring-emerald-200' },
  REJECTED: { badge: 'bg-rose-100 text-rose-800', dot: 'bg-rose-500', ring: 'ring-rose-200' },
  COMPLETED: { badge: 'bg-teal-100 text-teal-800', dot: 'bg-teal-500', ring: 'ring-teal-200' },
  CANCELLED: { badge: 'bg-muted text-muted-foreground', dot: 'bg-muted-foreground', ring: 'ring-muted-foreground/20' },
}

export default function PatientAppointments() {
  const { token, user, setActiveConversationId, setView } = useApp()
  const reduce = useReducedMotion()
  const [appts, setAppts] = useState<Appt[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(() => {
    if (!token) return
    setLoading(true)
    api<{ appointments: Appt[] }>('/api/appointments', {}, token)
      .then((r) => setAppts(r.appointments))
      .catch(() => setAppts([]))
      .finally(() => setLoading(false))
  }, [token])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load()
  }, [load])

  const chatWith = async (doctorId: string) => {
    if (!token) return
    try {
      const r = await api<{ conversation: any }>(
        '/api/conversations/list',
        { method: 'POST', body: JSON.stringify({ doctorId }) },
        token
      )
      setActiveConversationId(r.conversation.id)
      setView('chat')
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  return (
    <div className="space-y-4">
      {/* Header banner */}
      <div className="flex items-center justify-between gap-3 rounded-2xl bg-gradient-to-l from-teal-50 to-emerald-50/50 border border-teal-100 p-4">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white grid place-items-center shadow-md shadow-teal-600/20">
            <Calendar className="size-5" />
          </div>
          <div>
            <h2 className="font-bold text-teal-900">نوبت‌های من</h2>
            <p className="text-xs text-muted-foreground">وضعیت نوبت‌های ثبت‌شده شما</p>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={load} className="bg-white/70 border-teal-200 hover:bg-white">
          <RefreshCw className={`size-4 ml-2 ${loading ? 'animate-spin' : ''}`} /> به‌روزرسانی
        </Button>
      </div>

      {loading && (
        <div className="flex items-center justify-center py-16 text-muted-foreground">
          <Loader2 className="size-6 animate-spin ml-2" /> بارگذاری…
        </div>
      )}

      {!loading && appts.length === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-16"
        >
          <div className="size-20 rounded-2xl bg-teal-50 text-teal-600 grid place-items-center mx-auto mb-4 shadow-sm">
            <CalendarPlus className="size-9" />
          </div>
          <p className="font-medium text-foreground mb-1">هنوز نوبتی ثبت نکرده‌اید</p>
          <p className="text-sm text-muted-foreground mb-4">اولین نوبت خود را همین حالا رزرو کنید</p>
          <Button onClick={() => setView('book')} className="bg-gradient-to-l from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 shadow-md shadow-teal-600/20">
            <CalendarPlus className="size-4 ml-2" /> ثبت نوبت جدید
          </Button>
        </motion.div>
      )}

      {!loading && appts.length > 0 && (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="space-y-3"
        >
          <AnimatePresence>
            {appts.map((a) => {
              const style = STATUS_STYLE[a.status] || STATUS_STYLE.CANCELLED
              return (
                <motion.div
                  key={a.id}
                  variants={itemVariants}
                  layout
                  whileHover={reduce ? {} : { y: -3 }}
                  className={`rounded-2xl border-2 border-muted/10 bg-white p-4 shadow-sm hover:shadow-md transition-shadow ring-1 ${style.ring}`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <div className="flex items-start gap-3 w-full sm:flex-1">
                      <div className="relative size-11 rounded-xl bg-gradient-to-br from-teal-100 to-emerald-100 text-teal-700 grid place-items-center shrink-0">
                        <Stethoscope className="size-5" />
                        <span className={`absolute -bottom-0.5 -left-0.5 size-3 rounded-full ring-2 ring-white ${style.dot}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm sm:text-base">{a.doctor.name}</div>
                        <div className="text-xs text-muted-foreground">{a.doctor.specialty || 'دندان‌پزشک'}</div>
                        <div className="mt-1.5 text-xs sm:text-sm flex flex-wrap gap-x-3 gap-y-1">
                          <span className="inline-flex items-center gap-1 text-muted-foreground">
                            <Calendar className="size-3" /> {toJalali(a.date)}
                          </span>
                          <span className="inline-flex items-center gap-1 text-muted-foreground">
                            <Clock className="size-3" /> {toPersianDigits(a.startTime)} - {toPersianDigits(a.endTime)}
                          </span>
                        </div>
                        {a.reason && (
                          <div className="mt-1.5 text-xs text-muted-foreground flex items-start gap-1">
                            <span className="text-teal-600">علت:</span> {a.reason}
                          </div>
                        )}
                        {a.note && (
                          <div className="mt-1.5 text-xs text-amber-800 bg-amber-50 rounded-lg px-2 py-1.5 flex items-start gap-1.5">
                            <StickyNote className="size-3 shrink-0 mt-0.5" />
                            <span><span className="font-medium">یادداشت پزشک:</span> {a.note}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0">
                      <Badge className={`${style.badge} border-0 font-medium`}>{STATUS_LABEL[a.status] || a.status}</Badge>
                      {(a.status === 'PENDING' || a.status === 'APPROVED') && (
                        <Button size="sm" variant="outline" onClick={() => chatWith(a.doctor.id)} className="border-teal-200 hover:bg-teal-50 hover:text-teal-700">
                          <MessageCircle className="size-4 ml-1" /> چت
                        </Button>
                      )}
                    </div>
                  </div>
                </motion.div>
              )
            })}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  )
}

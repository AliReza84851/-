'use client'

import { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useApp, api } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent } from '@/components/ui/dialog'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Loader2, Stethoscope, User, Phone, ShieldCheck, ArrowRight, RefreshCw, CheckCircle2 } from 'lucide-react'
import { toast } from 'sonner'
import { toPersianDigits } from '@/lib/persian'

type Step = 'info' | 'verify'

export default function AuthDialog({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (o: boolean) => void
}) {
  const { setAuth } = useApp()
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [role, setRole] = useState<'PATIENT' | 'DOCTOR'>('PATIENT')
  const [step, setStep] = useState<Step>('info')
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [specialty, setSpecialty] = useState('')
  const [code, setCode] = useState('')
  const [devCode, setDevCode] = useState<string | null>(null)
  const [sent, setSent] = useState<boolean>(false)
  const [verifiedToken, setVerifiedToken] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [resendTimer, setResendTimer] = useState(0)
  const timerRef = useRef<any>(null)

  // Reset everything when dialog closes or mode changes
  const reset = () => {
    setStep('info')
    setName('')
    setPhone('')
    setPassword('')
    setSpecialty('')
    setCode('')
    setDevCode(null)
    setSent(false)
    setVerifiedToken(null)
    setResendTimer(0)
    if (timerRef.current) clearInterval(timerRef.current)
  }

  useEffect(() => {
    if (!open) reset()
  }, [open])

  // Resend countdown
  useEffect(() => {
    if (resendTimer > 0) {
      timerRef.current = setInterval(() => {
        setResendTimer((t) => (t > 0 ? t - 1 : 0))
      }, 1000)
      return () => {
        if (timerRef.current) clearInterval(timerRef.current)
      }
    } else if (timerRef.current) {
      clearInterval(timerRef.current)
    }
  }, [resendTimer])

  const validateInfo = (): boolean => {
    if (mode === 'register' && !name.trim()) {
      toast.error('نام و نام خانوادگی الزامی است')
      return false
    }
    if (!/^09\d{9}$/.test(phone.trim())) {
      toast.error('شماره موبایل معتبر نیست (مثال: 09123456789)')
      return false
    }
    if (password.length < 6) {
      toast.error('رمز عبور باید حداقل ۶ کاراکتر باشد')
      return false
    }
    return true
  }

  const sendCode = async () => {
    if (!validateInfo()) return
    setLoading(true)
    setDevCode(null)
    try {
      // For LOGIN: skip verification, login directly
      if (mode === 'login') {
        await completeLogin()
        return
      }
      // For REGISTER: send verification code
      const r: any = await api('/api/auth/verify-send', {
        method: 'POST',
        body: JSON.stringify({ phone: phone.trim(), mode }),
      })
      toast.success(r.message || 'کد تأیید به شماره شما ارسال شد')
      setDevCode(r.devCode || null)
      setSent(r.sent !== false)
      setResendTimer(120)
      setStep('verify')
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }

  // Direct login (no verification needed)
  const completeLogin = async () => {
    try {
      const r: any = await api('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ phone: phone.trim(), password }),
      })
      setAuth(r.token, r.user)
      toast.success('ورود با موفقیت انجام شد')
      onOpenChange(false)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }

  const verifyCode = async () => {
    if (!/^\d{6}$/.test(code.trim())) {
      toast.error('کد باید ۶ رقم باشد')
      return
    }
    setLoading(true)
    try {
      const r: any = await api('/api/auth/verify-check', {
        method: 'POST',
        body: JSON.stringify({ phone: phone.trim(), code: code.trim() }),
      })
      setVerifiedToken(r.verifiedToken)
      toast.success('شماره موبایل تأیید شد')
      // Now complete the auth flow
      await completeAuth(r.verifiedToken)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }

  const completeAuth = async (vToken: string) => {
    setLoading(true)
    try {
      // Only used for register (after phone verification)
      const endpoint = '/api/auth/register'
      const body: any = {
        phone: phone.trim(),
        password,
        verifiedToken: vToken,
        name: name.trim(),
        role,
      }
      if (role === 'DOCTOR') body.specialty = specialty.trim() || 'دندان‌پزشک عمومی'
      const r: any = await api(endpoint, {
        method: 'POST',
        body: JSON.stringify(body),
      })
      setAuth(r.token, r.user)
      toast.success('ثبت‌نام با موفقیت انجام شد')
      onOpenChange(false)
    } catch (e: any) {
      toast.error(e.message)
      setStep('verify')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md p-0 overflow-hidden gap-0">
        {/* Gradient header */}
        <div className="relative bg-gradient-to-br from-teal-600 via-teal-700 to-emerald-700 p-5 pb-6 text-white overflow-hidden">
          <motion.div
            className="absolute -top-8 -right-8 size-28 rounded-full bg-white/10 blur-2xl"
            animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
          />
          <motion.div
            className="absolute -bottom-8 -left-8 size-24 rounded-full bg-emerald-300/20 blur-2xl"
            animate={{ scale: [1, 1.15, 1], opacity: [0.2, 0.5, 0.2] }}
            transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
          />
          <div className="relative z-10 text-center">
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: 'spring', stiffness: 260, damping: 18 }}
              className="size-12 rounded-2xl bg-white/20 backdrop-blur grid place-items-center mx-auto mb-2"
            >
              <ShieldCheck className="size-6" />
            </motion.div>
            <h2 className="text-lg font-bold">
              {step === 'info' ? 'ورود / ثبت‌نام' : 'تأیید شماره موبایل'}
            </h2>
            <p className="text-white/80 text-xs mt-1">
              {step === 'info'
                ? 'برای استفاده از سامانه وارد شوید یا حساب بسازید'
                : `کد ۶ رقمی ارسال‌شده به ${toPersianDigits(phone)} را وارد کنید`}
            </p>
          </div>
        </div>

        <div className="p-5 space-y-4">
        <Tabs value={mode} onValueChange={(v) => { setMode(v as any); reset() }}>
          <TabsList className={`grid w-full grid-cols-2 ${step === 'verify' ? 'opacity-50 pointer-events-none' : ''}`}>
            <TabsTrigger value="login">ورود</TabsTrigger>
            <TabsTrigger value="register">ثبت‌نام</TabsTrigger>
          </TabsList>
        </Tabs>

        <AnimatePresence mode="wait">
          {step === 'info' && (
            <motion.div
              key="info"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-3 mt-3"
            >
              {mode === 'register' && (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    <motion.button
                      whileHover={{ y: -2 }}
                      whileTap={{ scale: 0.97 }}
                      type="button"
                      className={`flex items-center gap-2 p-3 rounded-xl border-2 text-sm transition-all ${
                        role === 'PATIENT' ? 'border-teal-500 bg-teal-50 shadow-sm shadow-teal-500/10' : 'border-transparent bg-muted/40 hover:bg-muted/70'
                      }`}
                      onClick={() => setRole('PATIENT')}
                    >
                      <div className={`size-8 rounded-lg grid place-items-center ${role === 'PATIENT' ? 'bg-gradient-to-br from-teal-500 to-teal-700 text-white' : 'bg-teal-100 text-teal-700'}`}>
                        <User className="size-4" />
                      </div>
                      بیمار
                    </motion.button>
                    <motion.button
                      whileHover={{ y: -2 }}
                      whileTap={{ scale: 0.97 }}
                      type="button"
                      className={`flex items-center gap-2 p-3 rounded-xl border-2 text-sm transition-all ${
                        role === 'DOCTOR' ? 'border-emerald-500 bg-emerald-50 shadow-sm shadow-emerald-500/10' : 'border-transparent bg-muted/40 hover:bg-muted/70'
                      }`}
                      onClick={() => setRole('DOCTOR')}
                    >
                      <div className={`size-8 rounded-lg grid place-items-center ${role === 'DOCTOR' ? 'bg-gradient-to-br from-emerald-500 to-emerald-700 text-white' : 'bg-emerald-100 text-emerald-700'}`}>
                        <Stethoscope className="size-4" />
                      </div>
                      پزشک
                    </motion.button>
                  </div>
                  <div>
                    <Label htmlFor="name">نام و نام خانوادگی</Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="مثلاً: علی رضایی"
                    />
                  </div>
                  {role === 'DOCTOR' && (
                    <div>
                      <Label htmlFor="spec">تخصص</Label>
                      <Input
                        id="spec"
                        value={specialty}
                        onChange={(e) => setSpecialty(e.target.value)}
                        placeholder="مثلاً: دندان‌پزشک اطفال"
                      />
                    </div>
                  )}
                </>
              )}
              <div>
                <Label htmlFor="phone">شماره موبایل</Label>
                <div className="relative">
                  <Input
                    id="phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="0912xxxxxxx"
                    dir="ltr"
                    inputMode="tel"
                    className="pl-9 text-left"
                  />
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                </div>
              </div>
              <div>
                <Label htmlFor="pass">رمز عبور</Label>
                <Input
                  id="pass"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="حداقل ۶ کاراکتر"
                  dir="ltr"
                  className="text-left"
                />
              </div>
            </motion.div>
          )}

          {step === 'verify' && (
            <motion.div
              key="verify"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4 mt-3"
            >
              <div className="flex flex-col items-center py-4">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="size-16 rounded-full bg-teal-100 text-teal-600 grid place-items-center mb-3"
                >
                  <ShieldCheck className="size-8" />
                </motion.div>
                <p className="text-sm text-muted-foreground text-center">
                  برای امنیت حساب شما، کد ۶ رقمی به شماره <span dir="ltr" className="font-medium text-foreground">{toPersianDigits(phone)}</span> ارسال شد
                </p>
                {sent && !devCode && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="mt-3 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-md px-3 py-2 text-center flex items-center justify-center gap-1"
                  >
                    <CheckCircle2 className="size-3.5" />
                    پیامک ارسال شد. کد را از روی گوشی خود وارد کنید.
                  </motion.div>
                )}
                {devCode && (
                  <div className="mt-3 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-md px-3 py-2 text-center">
                    <div className="font-medium mb-1">حالت دمو (بدون پیامک واقعی)</div>
                    <div>کد تأیید شما: <span dir="ltr" className="font-mono font-bold text-base">{toPersianDigits(devCode)}</span></div>
                    <div className="text-[10px] mt-1 text-amber-600">
                      برای ارسال واقعی پیامک، یک سرویس SMS را در فایل .env پیکربندی کنید.
                    </div>
                  </div>
                )}
              </div>
              <div>
                <Label htmlFor="code">کد تأیید</Label>
                <Input
                  id="code"
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  placeholder="۱۲۳۴۵۶"
                  dir="ltr"
                  inputMode="numeric"
                  className="text-center text-2xl font-bold tracking-[0.5em] bg-teal-50/40 border-teal-100 focus-visible:ring-teal-400"
                  maxLength={6}
                />
              </div>
              <div className="flex items-center justify-between text-xs">
                <button
                  type="button"
                  onClick={() => setStep('info')}
                  className="text-muted-foreground hover:text-foreground flex items-center gap-1"
                >
                  <ArrowRight className="size-3" /> تغییر شماره
                </button>
                <button
                  type="button"
                  disabled={resendTimer > 0 || loading}
                  onClick={sendCode}
                  className="text-teal-600 hover:text-teal-700 flex items-center gap-1 disabled:opacity-50"
                >
                  <RefreshCw className="size-3" />
                  {resendTimer > 0 ? `ارسال مجدد در ${toPersianDigits(resendTimer)} ثانیه` : 'ارسال مجدد کد'}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex gap-2 pt-2">
          {step === 'info' ? (
            <>
              <Button variant="outline" className="flex-1" onClick={() => onOpenChange(false)}>انصراف</Button>
              <Button onClick={sendCode} disabled={loading} className="flex-1 bg-gradient-to-l from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 shadow-md shadow-teal-600/20">
                {loading ? <Loader2 className="size-4 animate-spin ml-2" /> : null}
                {mode === 'login' ? 'ورود' : 'ارسال کد تأیید'}
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" className="flex-1" onClick={() => setStep('info')}>بازگشت</Button>
              <Button onClick={verifyCode} disabled={loading || code.length !== 6} className="flex-1 bg-gradient-to-l from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 shadow-md shadow-teal-600/20">
                {loading ? <Loader2 className="size-4 animate-spin ml-2" /> : <CheckCircle2 className="size-4 ml-2" />}
                تأیید و ثبت‌نام
              </Button>
            </>
          )}
        </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

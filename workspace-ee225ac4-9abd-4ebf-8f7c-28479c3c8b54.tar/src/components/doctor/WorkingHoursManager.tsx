'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion'
import { useApp, api } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Trash2, Plus, Loader2, Clock, CalendarDays, Zap } from 'lucide-react'
import { toast } from 'sonner'
import { PERSIAN_DAYS, toPersianDigits } from '@/lib/persian'
import { containerVariants, itemVariants } from '@/lib/motion'

interface WorkingHour {
  id: string
  dayOfWeek: number
  startTime: string
  endTime: string
  slotMinutes: number
  isActive: boolean
}

interface Draft {
  dayOfWeek: number
  startTime: string
  endTime: string
  slotMinutes: number
}

const DAY_COLORS = [
  'from-teal-500 to-teal-600',
  'from-cyan-500 to-cyan-600',
  'from-sky-500 to-sky-600',
  'from-blue-500 to-blue-600',
  'from-indigo-500 to-indigo-600',
  'from-violet-500 to-violet-600',
  'from-purple-500 to-purple-600',
]

export default function WorkingHoursManager() {
  const { token, user } = useApp()
  const reduce = useReducedMotion()
  const [hours, setHours] = useState<WorkingHour[]>([])
  const [loading, setLoading] = useState(true)
  const [draft, setDraft] = useState<Draft>({
    dayOfWeek: 0,
    startTime: '09:00',
    endTime: '13:00',
    slotMinutes: 30,
  })
  const [saving, setSaving] = useState(false)

  const load = () => {
    if (!token || !user) return
    setLoading(true)
    api<{ workingHours: WorkingHour[] }>(`/api/working-hours?doctorId=${user.id}`, {}, token)
      .then((r) => setHours(r.workingHours))
      .catch(() => setHours([]))
      .finally(() => setLoading(false))
  }
  useEffect(load, [token, user])

  const add = async () => {
    if (!token) return
    setSaving(true)
    try {
      await api(
        '/api/working-hours',
        {
          method: 'POST',
          body: JSON.stringify({
            dayOfWeek: draft.dayOfWeek,
            startTime: draft.startTime,
            endTime: draft.endTime,
            slotMinutes: Number(draft.slotMinutes),
            isActive: true,
          }),
        },
        token
      )
      toast.success('ساعت کاری افزوده شد')
      load()
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setSaving(false)
    }
  }

  const toggle = async (h: WorkingHour, v: boolean) => {
    if (!token) return
    try {
      await api(
        '/api/working-hours',
        {
          method: 'POST',
          body: JSON.stringify({ ...h, id: h.id, isActive: v }),
        },
        token
      )
      setHours((prev) => prev.map((x) => (x.id === h.id ? { ...x, isActive: v } : x)))
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const remove = async (id: string) => {
    if (!token) return
    try {
      await api(`/api/working-hours?id=${id}`, { method: 'DELETE' }, token)
      setHours((prev) => prev.filter((x) => x.id !== id))
      toast.success('حذف شد')
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const totalShifts = hours.length
  const activeShifts = hours.filter((h) => h.isActive).length

  return (
    <div className="space-y-4">
      {/* Header banner */}
      <div className="rounded-2xl bg-gradient-to-l from-teal-50 to-emerald-50/50 border border-teal-100 p-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white grid place-items-center shadow-md shadow-teal-600/20">
            <Clock className="size-5" />
          </div>
          <div>
            <h2 className="font-bold text-teal-900">ساعات کاری مطب</h2>
            <p className="text-xs text-muted-foreground">روزها و تایم‌هایی که مطب شما باز است</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Badge className="bg-teal-100 text-teal-800 border-0">{toPersianDigits(totalShifts)} شیفت</Badge>
          <Badge className="bg-emerald-100 text-emerald-800 border-0">{toPersianDigits(activeShifts)} فعال</Badge>
        </div>
      </div>

      {/* Add new form */}
      <motion.div
        initial={reduce ? false : { opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border-2 border-teal-100 bg-white p-4 space-y-3 shadow-sm"
      >
        <div className="flex items-center gap-2">
          <div className="size-8 rounded-lg bg-gradient-to-br from-teal-500 to-emerald-600 text-white grid place-items-center">
            <Plus className="size-4" />
          </div>
          <div className="font-medium text-sm">افزودن ساعت کاری جدید</div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div>
            <Label className="text-xs flex items-center gap-1"><CalendarDays className="size-3" /> روز هفته</Label>
            <select
              className="w-full mt-1 px-3 py-2 border rounded-lg bg-background text-sm focus:ring-2 focus:ring-teal-400 focus:border-teal-400 transition"
              value={draft.dayOfWeek}
              onChange={(e) => setDraft({ ...draft, dayOfWeek: Number(e.target.value) })}
            >
              {PERSIAN_DAYS.map((d, i) => (
                <option key={i} value={i}>{d}</option>
              ))}
            </select>
          </div>
          <div>
            <Label className="text-xs flex items-center gap-1"><Clock className="size-3" /> شروع</Label>
            <Input
              type="time"
              value={draft.startTime}
              onChange={(e) => setDraft({ ...draft, startTime: e.target.value })}
              className="mt-1"
            />
          </div>
          <div>
            <Label className="text-xs flex items-center gap-1"><Clock className="size-3" /> پایان</Label>
            <Input
              type="time"
              value={draft.endTime}
              onChange={(e) => setDraft({ ...draft, endTime: e.target.value })}
              className="mt-1"
            />
          </div>
          <div>
            <Label className="text-xs flex items-center gap-1"><Zap className="size-3" /> مدت اسلات (دقیقه)</Label>
            <Input
              type="number"
              value={draft.slotMinutes}
              onChange={(e) => setDraft({ ...draft, slotMinutes: Number(e.target.value) })}
              className="mt-1"
              min={10}
              step={5}
            />
          </div>
        </div>
        <div className="flex justify-end">
          <Button onClick={add} disabled={saving} className="bg-gradient-to-l from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 shadow-md shadow-teal-600/20">
            {saving ? <Loader2 className="size-4 animate-spin ml-2" /> : <Plus className="size-4 ml-2" />}
            افزودن
          </Button>
        </div>
      </motion.div>

      {/* Days grid */}
      {loading && (
        <div className="flex items-center justify-center py-16 text-muted-foreground">
          <Loader2 className="size-6 animate-spin ml-2" /> بارگذاری…
        </div>
      )}
      {!loading && (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3"
        >
          {PERSIAN_DAYS.map((dayName, dayIdx) => {
            const items = hours.filter((h) => h.dayOfWeek === dayIdx)
            const dayGrad = DAY_COLORS[dayIdx]
            const isOff = items.length === 0
            return (
              <motion.div
                key={dayIdx}
                variants={itemVariants}
                whileHover={reduce ? {} : { y: -3 }}
                className={`rounded-2xl border-2 bg-white p-3 shadow-sm transition-all ${isOff ? 'border-muted/30 opacity-70' : 'border-teal-100 hover:shadow-md'}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className={`size-8 rounded-lg bg-gradient-to-br ${dayGrad} text-white grid place-items-center text-xs font-bold shadow-sm`}>
                      {dayName[0]}
                    </div>
                    <div className="font-bold text-sm">{dayName}</div>
                  </div>
                  <Badge variant="outline" className={isOff ? 'text-muted-foreground' : 'text-teal-700 bg-teal-50'}>
                    {toPersianDigits(items.length)} شیفت
                  </Badge>
                </div>
                {isOff ? (
                  <div className="text-xs text-muted-foreground py-2 text-center bg-muted/30 rounded-lg">تعطیل</div>
                ) : (
                  <div className="space-y-2">
                    <AnimatePresence>
                      {items.map((h) => (
                        <motion.div
                          key={h.id}
                          layout
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -10 }}
                          className={`flex items-center gap-2 border rounded-lg p-2 transition-all ${h.isActive ? 'bg-teal-50/40 border-teal-100' : 'bg-muted/30 border-muted opacity-60'}`}
                        >
                          <div className={`size-7 rounded-md grid place-items-center text-[10px] font-bold shrink-0 ${h.isActive ? 'bg-gradient-to-br from-teal-500 to-emerald-600 text-white' : 'bg-muted text-muted-foreground'}`}>
                            <Clock className="size-3.5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-medium">{toPersianDigits(h.startTime)} - {toPersianDigits(h.endTime)}</div>
                            <div className="text-[10px] text-muted-foreground">اسلات: {toPersianDigits(h.slotMinutes)} دقیقه</div>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Switch checked={h.isActive} onCheckedChange={(v) => toggle(h, v)} />
                            <motion.button
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.9 }}
                              onClick={() => remove(h.id)}
                              className="size-7 grid place-items-center rounded-md hover:bg-rose-50 text-rose-500 transition"
                              aria-label="حذف"
                            >
                              <Trash2 className="size-3.5" />
                            </motion.button>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </motion.div>
            )
          })}
        </motion.div>
      )}
    </div>
  )
}

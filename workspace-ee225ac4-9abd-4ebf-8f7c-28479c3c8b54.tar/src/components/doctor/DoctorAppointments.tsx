'use client'

import { useCallback, useEffect, useState } from 'react'
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion'
import { useApp, api } from '@/lib/store'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent } from '@/components/ui/dialog'
import { Calendar, Clock, Check, X, MessageCircle, Loader2, RefreshCw, Phone, User, StickyNote } from 'lucide-react'
import { toast } from 'sonner'
import { toJalali, toPersianDigits } from '@/lib/persian'
import { EASE, containerVariants, itemVariants } from '@/lib/motion'

interface Appt {
  id: string
  date: string
  startTime: string
  endTime: string
  reason?: string
  status: string
  note?: string | null
  doctor: { id: string; name: string; specialty?: string | null }
  patient: { id: string; name: string; phone: string }
}

const STATUS_LABEL: Record<string, string> = {
  PENDING: 'در انتظار',
  APPROVED: 'تایید شده',
  REJECTED: 'رد شده',
  COMPLETED: 'تکمیل شده',
  CANCELLED: 'لغو شده',
}
const STATUS_STYLE: Record<string, { badge: string; dot: string }> = {
  PENDING: { badge: 'bg-amber-100 text-amber-800', dot: 'bg-amber-500' },
  APPROVED: { badge: 'bg-emerald-100 text-emerald-800', dot: 'bg-emerald-500' },
  REJECTED: { badge: 'bg-rose-100 text-rose-800', dot: 'bg-rose-500' },
  COMPLETED: { badge: 'bg-teal-100 text-teal-800', dot: 'bg-teal-500' },
  CANCELLED: { badge: 'bg-muted text-muted-foreground', dot: 'bg-muted-foreground' },
}

export default function DoctorAppointments() {
  const { token, user, setActiveConversationId, setView } = useApp()
  const reduce = useReducedMotion()
  const [appts, setAppts] = useState<Appt[]>([])
  const [loading, setLoading] = useState(true)
  const [noteDialog, setNoteDialog] = useState<{ appt: Appt; note: string; status: 'APPROVED' | 'REJECTED' | 'PENDING' | 'COMPLETED' } | null>(null)

  const load = useCallback(() => {
    if (!token) return
    setLoading(true)
    api<{ appointments: Appt[] }>('/api/appointments', {}, token)
      .then((r) => setAppts(r.appointments))
      .catch(() => setAppts([]))
      .finally(() => setLoading(false))
  }, [token])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load()
  }, [load])

  const updateStatus = async (appt: Appt, status: 'APPROVED' | 'REJECTED' | 'PENDING' | 'COMPLETED', note?: string) => {
    if (!token) return
    try {
      await api(
        `/api/appointments?id=${appt.id}`,
        {
          method: 'PATCH',
          body: JSON.stringify({ status, note: note ?? appt.note ?? '' }),
        },
        token
      )
      toast.success(`وضعیت نوبت به «${STATUS_LABEL[status]}» تغییر یافت`)
      setNoteDialog(null)
      load()
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const chatWith = async (patientId: string) => {
    if (!token) return
    try {
      const r = await api<{ conversation: any }>(
        '/api/conversations/list',
        { method: 'POST', body: JSON.stringify({ patientId }) },
        token
      )
      setActiveConversationId(r.conversation.id)
      setView('chat')
    } catch (e: any) {
      toast.error(e.message)
    }
  }

  const pending = appts.filter((a) => a.status === 'PENDING')
  const approved = appts.filter((a) => a.status === 'APPROVED')
  const others = appts.filter((a) => !['PENDING', 'APPROVED'].includes(a.status))

  const renderItem = (a: Appt) => {
    const style = STATUS_STYLE[a.status] || STATUS_STYLE.CANCELLED
    return (
      <motion.div
        key={a.id}
        layout
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        whileHover={reduce ? {} : { y: -3 }}
        className="rounded-2xl border-2 border-muted/10 bg-white p-4 shadow-sm hover:shadow-md transition-shadow"
      >
        <div className="flex items-start gap-3">
          <div className="relative size-11 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white grid place-items-center shrink-0 shadow-sm shadow-teal-600/20">
            <User className="size-5" />
            <span className={`absolute -bottom-0.5 -left-0.5 size-3 rounded-full ring-2 ring-white ${style.dot}`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-bold truncate text-sm sm:text-base">{a.patient.name}</div>
            <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
              <Phone className="size-3" /> <span dir="ltr">{toPersianDigits(a.patient.phone)}</span>
            </div>
            <div className="mt-1.5 text-xs sm:text-sm flex flex-wrap gap-x-3 gap-y-1">
              <span className="inline-flex items-center gap-1 text-muted-foreground">
                <Calendar className="size-3" /> {toJalali(a.date)}
              </span>
              <span className="inline-flex items-center gap-1 text-muted-foreground">
                <Clock className="size-3" /> {toPersianDigits(a.startTime)} - {toPersianDigits(a.endTime)}
              </span>
            </div>
            {a.reason && (
              <div className="mt-1.5 text-xs text-muted-foreground flex items-start gap-1">
                <span className="text-teal-600">علت:</span> {a.reason}
              </div>
            )}
            {a.note && (
              <div className="mt-1.5 text-xs text-amber-800 bg-amber-50 rounded-lg px-2 py-1.5 flex items-start gap-1.5">
                <StickyNote className="size-3 shrink-0 mt-0.5" />
                <span><span className="font-medium">یادداشت شما:</span> {a.note}</span>
              </div>
            )}
          </div>
          <Badge className={`${style.badge} border-0 shrink-0 self-start`}>{STATUS_LABEL[a.status] || a.status}</Badge>
        </div>
        {/* Action buttons */}
        <div className="grid grid-cols-2 sm:flex sm:flex-wrap gap-2 sm:gap-1.5 sm:justify-end mt-3">
          {a.status === 'PENDING' && (
            <>
              <Button size="sm" className="w-full sm:w-auto bg-gradient-to-l from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 shadow-sm" onClick={() => setNoteDialog({ appt: a, note: a.note || '', status: 'APPROVED' })}>
                <Check className="size-4 ml-1" /> تایید
              </Button>
              <Button size="sm" className="w-full sm:w-auto bg-gradient-to-l from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800 shadow-sm" onClick={() => setNoteDialog({ appt: a, note: a.note || '', status: 'REJECTED' })}>
                <X className="size-4 ml-1" /> رد
              </Button>
            </>
          )}
          {a.status === 'APPROVED' && (
            <Button size="sm" className="w-full sm:w-auto bg-gradient-to-l from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 shadow-sm" onClick={() => updateStatus(a, 'COMPLETED')}>
              <Check className="size-4 ml-1" /> تکمیل شد
            </Button>
          )}
          {(a.status === 'APPROVED' || a.status === 'COMPLETED') && (
            <Button size="sm" className="w-full sm:w-auto" variant="outline" onClick={() => updateStatus(a, 'PENDING')}>
              در انتظار
            </Button>
          )}
          <Button size="sm" className="w-full sm:w-auto border-teal-200 hover:bg-teal-50 hover:text-teal-700" variant="outline" onClick={() => chatWith(a.patient.id)}>
            <MessageCircle className="size-4 ml-1" /> چت
          </Button>
        </div>
      </motion.div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Header banner */}
      <div className="flex items-center justify-between gap-3 rounded-2xl bg-gradient-to-l from-teal-50 to-emerald-50/50 border border-teal-100 p-4">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white grid place-items-center shadow-md shadow-teal-600/20">
            <Calendar className="size-5" />
          </div>
          <div>
            <h2 className="font-bold text-teal-900">مدیریت نوبت‌ها</h2>
            <p className="text-xs text-muted-foreground">نوبت‌های ثبت‌شده توسط بیماران</p>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={load} className="bg-white/70 border-teal-200 hover:bg-white">
          <RefreshCw className={`size-4 ml-2 ${loading ? 'animate-spin' : ''}`} /> به‌روزرسانی
        </Button>
      </div>

      {loading && (
        <div className="flex items-center justify-center py-16 text-muted-foreground">
          <Loader2 className="size-6 animate-spin ml-2" /> بارگذاری…
        </div>
      )}

      {!loading && (
        <Tabs defaultValue="pending">
          <TabsList className="grid w-full grid-cols-3 h-auto bg-muted/40 rounded-xl p-1">
            <TabsTrigger value="pending" className="text-xs sm:text-sm px-2 sm:px-4 py-2 rounded-lg data-[state=active]:bg-gradient-to-l data-[state=active]:from-amber-500 data-[state=active]:to-orange-600 data-[state=active]:text-white data-[state=active]:shadow-sm transition-all">
              در انتظار ({toPersianDigits(pending.length)})
            </TabsTrigger>
            <TabsTrigger value="approved" className="text-xs sm:text-sm px-2 sm:px-4 py-2 rounded-lg data-[state=active]:bg-gradient-to-l data-[state=active]:from-emerald-500 data-[state=active]:to-emerald-600 data-[state=active]:text-white data-[state=active]:shadow-sm transition-all">
              تایید شده ({toPersianDigits(approved.length)})
            </TabsTrigger>
            <TabsTrigger value="others" className="text-xs sm:text-sm px-2 sm:px-4 py-2 rounded-lg data-[state=active]:bg-gradient-to-l data-[state=active]:from-teal-500 data-[state=active]:to-teal-600 data-[state=active]:text-white data-[state=active]:shadow-sm transition-all">
              سایر ({toPersianDigits(others.length)})
            </TabsTrigger>
          </TabsList>
          <TabsContent value="pending" className="space-y-3 mt-4">
            <AnimatePresence mode="popLayout">
              {pending.length === 0 ? (
                <div className="text-center py-10 text-muted-foreground">نوبت در انتظاری وجود ندارد</div>
              ) : (
                pending.map(renderItem)
              )}
            </AnimatePresence>
          </TabsContent>
          <TabsContent value="approved" className="space-y-3 mt-4">
            <AnimatePresence mode="popLayout">
              {approved.length === 0 ? (
                <div className="text-center py-10 text-muted-foreground">نوبت تاییدشده‌ای وجود ندارد</div>
              ) : (
                approved.map(renderItem)
              )}
            </AnimatePresence>
          </TabsContent>
          <TabsContent value="others" className="space-y-3 mt-4">
            <AnimatePresence mode="popLayout">
              {others.length === 0 ? (
                <div className="text-center py-10 text-muted-foreground">موردی وجود ندارد</div>
              ) : (
                others.map(renderItem)
              )}
            </AnimatePresence>
          </TabsContent>
        </Tabs>
      )}

      {/* note dialog for approve/reject */}
      <Dialog open={!!noteDialog} onOpenChange={(o) => !o && setNoteDialog(null)}>
        <DialogContent className="max-w-md p-0 overflow-hidden gap-0">
          <div className={`p-5 text-white ${noteDialog?.status === 'APPROVED' ? 'bg-gradient-to-br from-emerald-600 to-emerald-700' : 'bg-gradient-to-br from-rose-600 to-rose-700'}`}>
            <div className="flex items-center gap-2">
              {noteDialog?.status === 'APPROVED' ? <Check className="size-5" /> : <X className="size-5" />}
              <h2 className="font-bold">
                {noteDialog?.status === 'APPROVED' ? 'تایید نوبت' : 'رد نوبت'}
              </h2>
            </div>
          </div>
          <div className="p-5 space-y-3">
            <p className="text-sm text-muted-foreground">
              آیا از {noteDialog?.status === 'APPROVED' ? 'تایید' : 'رد'} این نوبت مطمئن هستید؟
            </p>
            <Textarea
              placeholder="یادداشت اختیاری برای بیمار…"
              value={noteDialog?.note || ''}
              onChange={(e) => setNoteDialog((p) => (p ? { ...p, note: e.target.value } : p))}
              rows={3}
              className="resize-none"
            />
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setNoteDialog(null)}>
                انصراف
              </Button>
              <Button
                className={`flex-1 ${noteDialog?.status === 'APPROVED' ? 'bg-gradient-to-l from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800' : 'bg-gradient-to-l from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800'} shadow-md`}
                onClick={() => noteDialog && updateStatus(noteDialog.appt, noteDialog.status, noteDialog.note)}
              >
                {noteDialog?.status === 'APPROVED' ? 'تایید کن' : 'رد کن'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

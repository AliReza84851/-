'use client'

import { useEffect, useState } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { toast } from 'sonner'
import { useApp, api } from '@/lib/store'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import {
  Calendar,
  CalendarClock,
  MessageCircle,
  Clock,
  Stethoscope,
  Smile,
  ArrowLeft,
  Users,
  TrendingUp,
} from 'lucide-react'
import { toPersianDigits } from '@/lib/persian'
import { EASE, containerVariants, itemVariants, AnimatedNumber } from '@/lib/motion'

function getInitials(name: string): string {
  const trimmed = (name || '').trim()
  return trimmed ? trimmed.slice(0, 2) : '؟'
}

export default function HomeDashboard() {
  const { user, setView, token } = useApp()
  const reduce = useReducedMotion()
  const [stats, setStats] = useState<{ total: number; pending: number; approved: number; unread: number }>({
    total: 0, pending: 0, approved: 0, unread: 0,
  })

  useEffect(() => {
    if (!token || !user) return
    Promise.all([
      api<{ appointments: any[] }>('/api/appointments', {}, token).catch(() => ({ appointments: [] })),
      api<{ conversations: any[] }>('/api/conversations/list', {}, token).catch(() => ({ conversations: [] })),
    ]).then(([a, c]) => {
      const appts = a.appointments || []
      setStats({
        total: appts.length,
        pending: appts.filter((x: any) => x.status === 'PENDING').length,
        approved: appts.filter((x: any) => x.status === 'APPROVED').length,
        unread: (c.conversations || []).reduce((s: number, x: any) => s + (x.unread || 0), 0),
      })
    })
  }, [token, user])

  if (!user) return null
  const isDoctor = user.role === 'DOCTOR'

  const cards: { view: any; title: string; desc: string; icon: any; tone: 'teal' | 'emerald' | 'amber' | 'rose'; badge?: string }[] = isDoctor
    ? [
        { view: 'manage-appointments', title: 'مدیریت نوبت‌ها', desc: 'تأیید، رد یا مدیریت نوبت‌های بیماران', icon: Calendar, tone: 'teal', badge: stats.pending > 0 ? `${toPersianDigits(stats.pending)} در انتظار` : undefined },
        { view: 'working-hours', title: 'ساعات کاری', desc: 'تنظیم روزها و تایم‌های باز مطب', icon: Clock, tone: 'emerald' },
        { view: 'chat', title: 'چت با بیماران', desc: 'پاسخ به سوالات بیماران و گفتگو', icon: MessageCircle, tone: 'amber', badge: stats.unread > 0 ? `${toPersianDigits(stats.unread)} جدید` : undefined },
      ]
    : [
        { view: 'book', title: 'رزرو نوبت', desc: 'انتخاب پزشک و ثبت نوبت جدید', icon: Calendar, tone: 'teal' },
        { view: 'my-appointments', title: 'نوبت‌های من', desc: 'مشاهده وضعیت نوبت‌های ثبت‌شده', icon: CalendarClock, tone: 'emerald', badge: stats.total > 0 ? `${toPersianDigits(stats.total)} نوبت` : undefined },
        { view: 'chat', title: 'چت با پزشک', desc: 'گفتگوی مستقیم با پزشک', icon: MessageCircle, tone: 'amber', badge: stats.unread > 0 ? `${toPersianDigits(stats.unread)} جدید` : undefined },
      ]

  const gradMap = {
    teal: 'from-teal-500 to-teal-700',
    emerald: 'from-emerald-500 to-emerald-700',
    amber: 'from-amber-500 to-orange-600',
    rose: 'from-rose-500 to-rose-700',
  }
  const softBg = {
    teal: 'bg-teal-50 text-teal-700',
    emerald: 'bg-emerald-50 text-emerald-700',
    amber: 'bg-amber-50 text-amber-700',
    rose: 'bg-rose-50 text-rose-700',
  }

  return (
    <div className="space-y-6">
      {/* Welcome hero */}
      <motion.div
        initial={reduce ? false : { opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-teal-600 via-teal-700 to-emerald-700 text-white p-6 sm:p-8 shadow-xl shadow-teal-700/25"
      >
        {/* animated mesh background */}
        <motion.div
          className="absolute -top-16 -right-16 size-56 rounded-full bg-white/15 blur-3xl"
          animate={reduce ? {} : { scale: [1, 1.25, 1], opacity: [0.3, 0.6, 0.3], rotate: [0, 90, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute -bottom-16 -left-16 size-64 rounded-full bg-emerald-300/25 blur-3xl"
          animate={reduce ? {} : { scale: [1, 1.2, 1], opacity: [0.2, 0.5, 0.2], rotate: [0, -60, 0] }}
          transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
        />
        <motion.div
          className="absolute top-1/3 left-1/4 size-32 rounded-full bg-cyan-200/15 blur-2xl"
          animate={reduce ? {} : { y: [0, -20, 0], opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
        />
        <div className="relative z-10 flex items-center gap-4">
          <Avatar className="size-14 sm:size-16 ring-4 ring-white/30 shadow-lg">
            <AvatarFallback className="bg-white text-teal-700 text-xl sm:text-2xl font-bold">
              {getInitials(user.name)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <motion.h2
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.15, duration: 0.5 }}
              className="text-xl sm:text-2xl font-bold"
            >
              سلام {user.name} 👋
            </motion.h2>
            <div className="text-white/80 text-sm mt-0.5 flex items-center gap-2">
              <Badge className="bg-white/20 hover:bg-white/20 text-white border-0 backdrop-blur">
                {isDoctor ? <Stethoscope className="size-3 ml-1" /> : <Smile className="size-3 ml-1" />}
                {isDoctor ? 'پزشک' : 'بیمار'}
              </Badge>
              {isDoctor && user.specialty && (
                <span className="hidden sm:inline truncate">{user.specialty}</span>
              )}
            </div>
          </div>
        </div>
        <p className="relative z-10 text-white/85 text-sm mt-4">
          {isDoctor
            ? 'به پنل مدیریت پزشک خوش آمدید. از اینجا می‌توانید نوبت‌ها را مدیریت کنید، ساعات کاری را تنظیم کنید و با بیماران چت کنید.'
            : 'به سامانه نوبت‌دهی خوش آمدید. از اینجا می‌توانید نوبت بگیرید، نوبت‌های قبلی را ببینید و با پزشک چت کنید.'}
        </p>
      </motion.div>

      {/* Quick stats with count-up */}
      {isDoctor && (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="grid grid-cols-3 gap-2 sm:gap-3"
        >
          <StatCard label="کل نوبت‌ها" value={stats.total} icon={TrendingUp} tone="teal" delay={0.1} />
          <StatCard label="در انتظار" value={stats.pending} icon={Clock} tone="amber" delay={0.18} />
          <StatCard label="تایید شده" value={stats.approved} icon={Calendar} tone="emerald" delay={0.26} />
        </motion.div>
      )}

      {/* Navigation cards */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="grid sm:grid-cols-3 gap-3 sm:gap-4"
      >
        {cards.map((c, i) => {
          const Icon = c.icon
          return (
            <motion.button
              key={c.view}
              variants={itemVariants}
              whileHover={reduce ? {} : { y: -6 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setView(c.view)}
              className="text-right border-2 border-teal-50 rounded-2xl bg-white p-5 shadow-sm hover:shadow-xl hover:shadow-teal-600/10 transition-all relative overflow-hidden group"
            >
              <div className="absolute -top-8 -left-8 size-24 rounded-full bg-teal-50/60 blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute top-0 inset-x-0 h-0.5 bg-gradient-to-l from-transparent via-teal-400 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative z-10">
                <div className="flex items-start justify-between mb-3">
                  <motion.div
                    whileHover={reduce ? {} : { rotate: 12, scale: 1.1 }}
                    transition={{ type: 'spring', stiffness: 400, damping: 12 }}
                    className={`size-12 rounded-2xl bg-gradient-to-br ${gradMap[c.tone]} text-white grid place-items-center shadow-md shadow-teal-600/20`}
                  >
                    <Icon className="size-6" />
                  </motion.div>
                  {c.badge && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', stiffness: 500, damping: 20, delay: 0.3 }}
                    >
                      <Badge className={`${softBg[c.tone]} border-0 text-xs`}>{c.badge}</Badge>
                    </motion.div>
                  )}
                </div>
                <h3 className="font-bold mb-1">{c.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{c.desc}</p>
                <div className="mt-3 flex items-center gap-1 text-teal-600 text-sm font-medium">
                  شروع
                  <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
                </div>
              </div>
            </motion.button>
          )
        })}
      </motion.div>

      {/* Shortcuts */}
      <motion.div
        initial={reduce ? false : { opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4, ease: EASE }}
      >
        <Card className="p-5 border-teal-50 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <div className="size-8 rounded-lg bg-gradient-to-br from-teal-100 to-emerald-100 text-teal-700 grid place-items-center">
              <Users className="size-4" />
            </div>
            <h3 className="font-bold">میان‌برها</h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { label: 'راهنمای استفاده', icon: Smile, action: () => toast('سامانه نوبت‌دهی آنلاین مطب دندان‌پزشکی') },
              { label: 'پشتیبانی', icon: MessageCircle, action: () => setView('chat') },
              { label: 'تنظیمات', icon: Clock, action: () => toast('به‌زودی!') },
              { label: 'خروج', icon: ArrowLeft, action: () => useApp.getState().clearAuth() },
            ].map((s, i) => {
              const Icon = s.icon
              return (
                <motion.button
                  key={i}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={s.action}
                  className="flex items-center gap-2 p-2.5 rounded-lg hover:bg-teal-50/60 transition text-sm text-muted-foreground hover:text-teal-700"
                >
                  <Icon className="size-4 text-teal-600" />
                  <span>{s.label}</span>
                </motion.button>
              )
            })}
          </div>
        </Card>
      </motion.div>
    </div>
  )
}

// Stats card with animated count-up
function StatCard({ label, value, icon: Icon, tone, delay = 0 }: { label: string; value: number; icon: any; tone: 'teal' | 'emerald' | 'amber'; delay?: number }) {
  const gradMap = {
    teal: 'from-teal-500 to-teal-700',
    emerald: 'from-emerald-500 to-emerald-700',
    amber: 'from-amber-500 to-orange-600',
  }
  return (
    <motion.div
      variants={itemVariants}
      className="relative overflow-hidden"
    >
      <Card className="p-3 sm:p-4 flex items-center gap-2 sm:gap-3 border-teal-50 shadow-sm hover:shadow-md transition-shadow">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 400, damping: 15, delay }}
          className={`size-8 sm:size-10 rounded-lg bg-gradient-to-br ${gradMap[tone]} text-white grid place-items-center shrink-0 shadow-sm`}
        >
          <Icon className="size-4 sm:size-5" />
        </motion.div>
        <div className="min-w-0">
          <div className="text-base sm:text-xl font-bold leading-tight">
            <AnimatedNumber value={value} />
          </div>
          <div className="text-[10px] sm:text-xs text-muted-foreground truncate">{label}</div>
        </div>
      </Card>
    </motion.div>
  )
}

'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion'
import { useApp, api } from '@/lib/store'
import { Card } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Input } from '@/components/ui/input'
import { Loader2, MessageCircle, Search, Users, FileText, ImageIcon } from 'lucide-react'
import { toPersianDigits } from '@/lib/persian'

// Parse a message content - returns a friendly preview string for file/image messages
function previewMessage(raw: string | null): { text: string; isFile: boolean; isImage: boolean } {
  if (!raw) return { text: 'بدون پیام', isFile: false, isImage: false }
  const trimmed = raw.trim()
  if (trimmed.startsWith('{"_file":')) {
    try {
      const obj = JSON.parse(trimmed)
      if (obj && obj._file) {
        const mime = String(obj.mime || '')
        const isImage = mime.startsWith('image/')
        const name = String(obj.name || 'فایل')
        return {
          text: isImage ? `🖼️ ${name}` : `📎 ${name}`,
          isFile: !isImage,
          isImage,
        }
      }
    } catch {
      // fallthrough
    }
  }
  return { text: raw, isFile: false, isImage: false }
}

interface ConversationListItem {
  id: string
  doctor: { id: string; name: string; specialty?: string | null }
  patient: { id: string; name: string; phone: string }
  lastMessage: string | null
  lastMessageAt: string
  unread: number
}

const EASE = [0.22, 1, 0.36, 1] as const

function getInitials(name: string): string {
  const trimmed = (name || '').trim()
  if (!trimmed) return '؟'
  return trimmed.slice(0, 2)
}

function formatRelativeTime(iso: string): string {
  try {
    const d = new Date(iso)
    const now = new Date()
    const diffMin = Math.floor((now.getTime() - d.getTime()) / 60000)
    if (diffMin < 1) return 'اکنون'
    if (diffMin < 60) return `${toPersianDigits(diffMin)} دقیقه`
    const isToday =
      d.getFullYear() === now.getFullYear() &&
      d.getMonth() === now.getMonth() &&
      d.getDate() === now.getDate()
    if (isToday) {
      return toPersianDigits(d.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }))
    }
    const yesterday = new Date(now)
    yesterday.setDate(now.getDate() - 1)
    const isYesterday =
      d.getFullYear() === yesterday.getFullYear() &&
      d.getMonth() === yesterday.getMonth() &&
      d.getDate() === yesterday.getDate()
    if (isYesterday) return 'دیروز'
    return new Intl.DateTimeFormat('fa-IR', { day: 'numeric', month: 'short' }).format(d)
  } catch {
    return ''
  }
}

export default function ConversationList({
  onSelect,
  selectedId,
  refreshKey = 0,
}: {
  onSelect: (id: string) => void
  selectedId: string | null
  refreshKey?: number
}) {
  const { token, user } = useApp()
  const reduce = useReducedMotion()
  const [items, setItems] = useState<ConversationListItem[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  const load = useCallback(() => {
    if (!token) return
    setLoading(true)
    api<{ conversations: ConversationListItem[] }>('/api/conversations/list', {}, token)
      .then((r) => setItems(r.conversations))
      .catch(() => setItems([]))
      .finally(() => setLoading(false))
  }, [token])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load()
  }, [load, refreshKey])

  // Filter by search
  const filtered = useMemo(() => {
    if (!search.trim()) return items
    const q = search.trim()
    return items.filter((c) => {
      const peer = user?.role === 'DOCTOR' ? c.patient : c.doctor
      return peer.name.includes(q) || (c.lastMessage || '').includes(q)
    })
  }, [items, search, user])

  const totalUnread = useMemo(() => items.reduce((sum, c) => sum + c.unread, 0), [items])

  if (loading) {
    return (
      <Card className="p-6 flex items-center justify-center text-muted-foreground h-full">
        <Loader2 className="size-4 animate-spin ml-2" /> بارگذاری مکالمات…
      </Card>
    )
  }

  return (
    <Card className="p-0 overflow-hidden h-full flex flex-col border-teal-100 shadow-md">
      {/* Header */}
      <div className="px-4 py-3 border-b bg-gradient-to-l from-teal-50 to-white">
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <div className="size-8 rounded-lg bg-gradient-to-br from-teal-500 to-emerald-600 text-white grid place-items-center shadow-sm">
              <Users className="size-4" />
            </div>
            <div>
              <div className="font-semibold leading-tight">مکالمات</div>
              <div className="text-[10px] text-muted-foreground">
                {toPersianDigits(items.length)} مکالمه
                {totalUnread > 0 && (
                  <span className="text-rose-600 font-medium">
                    {' '}
                    · {toPersianDigits(totalUnread)} خوانده‌نشده
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Search box */}
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground pointer-events-none" />
          <Input
            placeholder="جستجو در مکالمات…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-9 bg-muted/40 border-0 focus-visible:ring-1 focus-visible:ring-teal-400 rounded-full text-sm"
          />
        </div>
      </div>

      {/* List */}
      <ScrollArea className="flex-1 max-h-[58vh]">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-muted-foreground h-full py-10 px-4 text-center">
            <div className="size-14 rounded-2xl bg-teal-50 text-teal-600 grid place-items-center mb-3">
              <MessageCircle className="size-7" />
            </div>
            <p className="font-medium text-foreground mb-1">مکالمه‌ای یافت نشد</p>
            <p className="text-xs">
              {search
                ? 'عبارت جستجو با هیچ مکالمه‌ای مطابقت ندارد.'
                : user?.role === 'PATIENT'
                ? 'بعد از رزرو نوبت می‌توانید با پزشک چت کنید'
                : 'بیماران پس از رزرو نوبت با شما چت خواهند کرد'}
            </p>
          </div>
        ) : (
          <ul className="divide-y">
            <AnimatePresence initial={false}>
              {filtered.map((c) => {
                const peer = user?.role === 'DOCTOR' ? c.patient : c.doctor
                const selected = selectedId === c.id
                const hasUnread = c.unread > 0
                return (
                  <motion.li
                    key={c.id}
                    initial={reduce ? false : { opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, ease: EASE }}
                    layout
                    className={`cursor-pointer px-3 py-3 transition relative ${
                      selected
                        ? 'bg-teal-50'
                        : 'hover:bg-accent/60'
                    }`}
                    onClick={() => onSelect(c.id)}
                  >
                    {/* Active indicator bar */}
                    {selected && (
                      <motion.span
                        layoutId="conv-active-bar"
                        className="absolute right-0 top-2 bottom-2 w-1 rounded-full bg-teal-600"
                      />
                    )}
                    <div className="flex items-center gap-3">
                      {/* Avatar */}
                      <div className="relative shrink-0">
                        <Avatar className={`size-11 ring-2 ${selected ? 'ring-teal-300' : 'ring-transparent'}`}>
                          <AvatarFallback className="bg-gradient-to-br from-teal-500 to-emerald-600 text-white text-xs font-bold">
                            {getInitials(peer.name)}
                          </AvatarFallback>
                        </Avatar>
                        {/* Online dot (optimistic) */}
                        <span className="absolute -bottom-0.5 -left-0.5 size-3 rounded-full bg-emerald-500 ring-2 ring-white" />
                      </div>
                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <div className="font-medium truncate text-sm">{peer.name}</div>
                          <span className={`text-[10px] shrink-0 ${hasUnread ? 'text-teal-600 font-medium' : 'text-muted-foreground'}`}>
                            {formatRelativeTime(c.lastMessageAt)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between gap-2 mt-0.5">
                          <div className={`text-xs truncate flex items-center gap-1 ${hasUnread ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>
                            {(() => {
                              const p = previewMessage(c.lastMessage)
                              return (
                                <>
                                  {p.isImage && <ImageIcon className="size-3 shrink-0" />}
                                  {p.isFile && <FileText className="size-3 shrink-0" />}
                                  <span className="truncate">{p.text}</span>
                                </>
                              )
                            })()}
                          </div>
                          {hasUnread && (
                            <Badge className="bg-rose-500 hover:bg-rose-500 text-white rounded-full px-1.5 py-0 text-[10px] min-w-[18px] h-[18px] grid place-items-center shrink-0">
                              {toPersianDigits(c.unread)}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.li>
                )
              })}
            </AnimatePresence>
          </ul>
        )}
      </ScrollArea>
    </Card>
  )
}

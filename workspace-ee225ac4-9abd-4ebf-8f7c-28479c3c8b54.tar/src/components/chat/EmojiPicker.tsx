'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'

interface EmojiPickerProps {
  onSelect: (emoji: string) => void
  onClose?: () => void
}

const CATEGORIES = [
  {
    name: 'چهره‌ها',
    emojis: ['😀', '😂', '😍', '🤣', '😊', '🙂', '😉', '🙃', '😇', '🥰', '😎', '🤩', '😘', '😋', '😝', '🤔', '🤨', '😐', '😴', '🥱', '😢', '😭', '😡', '🤬', '🥺', '😳', '😱', '😨', '😰', '😅', '😓', '🙄', '😬', '🤥', '😞', '😔', '😟', '😕', '🙁', '☹️'],
  },
  {
    name: 'سلامت',
    emojis: ['🦷', '💉', '🩺', '🏥', '💊', '🩹', '🦴', '🧠', '❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '👍', '👎', '👌', '✌️', '🤞', '🤟', '🤙', '👋', '🙏', '💪', '✊', '🤝'],
  },
  {
    name: 'اشیا',
    emojis: ['⏰', '📅', '📆', '🗒️', '📝', '✏️', '📌', '📎', '📂', '📁', '📷', '📸', '🎥', '☎️', '📞', '📱', '💻', '🖥️', '⌨️', '🖱️', '💡', '🔔', '🎁', '🎉', '🎊', '🎈', '🎂', '🍰', '☕', '🍵', '🥤', '🍽️', '🛏️', '🚗', '🏠', '🏥'],
  },
  {
    name: 'نمادها',
    emojis: ['✅', '❌', '❓', '❗', '⚠️', '⭕', '🔴', '🟢', '🟡', '🔵', '⚪', '⚫', '🔶', '🔷', '🔹', '🔸', '💠', '✨', '⭐', '🌟', '💫', '🔥', '💯', '🆗', '🆕', '🆒', '🆓', '⬆️', '⬇️', '➡️', '⬅️', '🔁', '🔄', '❤', '☑️', '✔️'],
  },
]

export default function EmojiPicker({ onSelect, onClose }: EmojiPickerProps) {
  const [cat, setCat] = useState(0)
  const current = CATEGORIES[cat]

  return (
    <motion.div
      initial={{ opacity: 0, y: 8, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 8, scale: 0.95 }}
      transition={{ duration: 0.15 }}
      className="w-72 rounded-2xl border bg-white shadow-xl overflow-hidden"
      onMouseLeave={onClose}
    >
      {/* Category tabs */}
      <div className="flex border-b bg-muted/30 overflow-x-auto">
        {CATEGORIES.map((c, i) => (
          <button
            key={c.name}
            onClick={() => setCat(i)}
            className={`px-3 py-2 text-xs whitespace-nowrap transition ${
              i === cat ? 'bg-white text-teal-700 font-medium border-b-2 border-teal-600' : 'text-muted-foreground hover:bg-white/50'
            }`}
          >
            {c.name}
          </button>
        ))}
      </div>
      {/* Emojis grid */}
      <div className="grid grid-cols-8 gap-0.5 p-2 max-h-56 overflow-y-auto">
        {current.emojis.map((e, i) => (
          <button
            key={i}
            onClick={() => onSelect(e)}
            className="size-8 grid place-items-center text-xl rounded hover:bg-teal-50 hover:scale-110 transition active:scale-95"
          >
            {e}
          </button>
        ))}
      </div>
    </motion.div>
  )
}

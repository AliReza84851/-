'use client'

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { io, Socket } from 'socket.io-client'
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion'
import { useApp, api } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog'
import {
  Send,
  ArrowRight,
  Loader2,
  Check,
  CheckCheck,
  MoreVertical,
  Smile,
  Paperclip,
  FileText,
  Image as ImageIcon,
  Download,
  Trash2,
  Info,
  BellOff,
  Ban,
  ShieldCheck,
} from 'lucide-react'
import { toast } from 'sonner'
import { toPersianDigits } from '@/lib/persian'
import EmojiPicker from './EmojiPicker'

interface Message {
  id: string
  conversationId: string
  senderId: string
  content: string
  createdAt: string
  isRead?: boolean
  senderRole?: 'DOCTOR' | 'PATIENT'
}

interface ConversationListItem {
  id: string
  doctor: { id: string; name: string; specialty?: string | null; phone?: string }
  patient: { id: string; name: string; phone: string }
  lastMessage: string | null
  lastMessageAt: string
  unread: number
}

interface ChatPanelProps {
  conversationId: string | null
  onBack?: () => void
}

interface ParsedContent {
  kind: 'text' | 'file' | 'image'
  text?: string
  fileName?: string
  fileSize?: number
  fileMime?: string
  fileData?: string
}

const EASE = [0.22, 1, 0.36, 1] as const
const MAX_FILE_SIZE = 1024 * 1024 // 1 MB

function getInitials(name: string): string {
  const trimmed = (name || '').trim()
  return trimmed ? trimmed.slice(0, 2) : '؟'
}

function formatClockTime(iso: string): string {
  try {
    return toPersianDigits(
      new Date(iso).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
    )
  } catch {
    return ''
  }
}

function formatJalaliDay(iso: string): string {
  try {
    return new Intl.DateTimeFormat('fa-IR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
    }).format(new Date(iso))
  } catch {
    return ''
  }
}

function getDayKey(iso: string): string {
  try {
    return new Date(iso).toISOString().slice(0, 10)
  } catch {
    return ''
  }
}

function isToday(iso: string): boolean {
  try {
    const d = new Date(iso)
    const now = new Date()
    return (
      d.getFullYear() === now.getFullYear() &&
      d.getMonth() === now.getMonth() &&
      d.getDate() === now.getDate()
    )
  } catch {
    return false
  }
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${toPersianDigits(bytes)} بایت`
  if (bytes < 1024 * 1024) return `${toPersianDigits((bytes / 1024).toFixed(1))} کیلوبایت`
  return `${toPersianDigits((bytes / (1024 * 1024)).toFixed(1))} مگابایت`
}

function parseContent(raw: string): ParsedContent {
  const trimmed = (raw || '').trim()
  if (!trimmed) return { kind: 'text', text: '' }
  if (trimmed.startsWith('{"_file":')) {
    try {
      const obj = JSON.parse(trimmed)
      if (obj && obj._file) {
        const mime = String(obj.mime || '')
        const isImage = mime.startsWith('image/')
        return {
          kind: isImage ? 'image' : 'file',
          fileName: obj.name,
          fileSize: obj.size,
          fileMime: mime,
          fileData: obj.data,
        }
      }
    } catch {
      // fallthrough
    }
  }
  return { kind: 'text', text: raw }
}

const QUICK_REPLIES_PATIENT = ['سلام، وقت بخیر', 'چه زمانی به مطب بیایم؟', 'ممنون از شما']
const QUICK_REPLIES_DOCTOR = ['سلام وقت بخیر', 'لطفا ۱۵ دقیقه زودتر بیایید', 'نوبت تایید شد']

export default function ChatPanel({ conversationId, onBack }: ChatPanelProps) {
  const { token, user } = useApp()
  const reduce = useReducedMotion()
  const [socket, setSocket] = useState<Socket | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [text, setText] = useState('')
  const [peerTyping, setPeerTyping] = useState(false)
  const [peerName, setPeerName] = useState<string>('')
  const [peerRole, setPeerRole] = useState<'DOCTOR' | 'PATIENT' | null>(null)
  const [peerPhone, setPeerPhone] = useState<string>('')
  const [peerId, setPeerId] = useState<string>('')
  const [peerOnline, setPeerOnline] = useState(false)
  const [loading, setLoading] = useState(false)
  const [sending, setSending] = useState(false)
  const [emojiOpen, setEmojiOpen] = useState(false)
  const [confirmClear, setConfirmClear] = useState(false)
  const [contactInfoOpen, setContactInfoOpen] = useState(false)
  const [iBlockedPeer, setIBlockedPeer] = useState(false) // current user blocked the peer
  const [peerBlockedMe, setPeerBlockedMe] = useState(false) // peer blocked current user
  const [blockCheckLoading, setBlockCheckLoading] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const lastTypingRef = useRef<number>(0)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const s = io('/?XTransformPort=3003', {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 3,
      timeout: 10000,
    })
    setSocket(s)
    return () => {
      s.disconnect()
    }
  }, [])

  useEffect(() => {
    if (socket && user) {
      socket.emit('auth', { userId: user.id, role: user.role, name: user.name })
    }
  }, [socket, user])

  useEffect(() => {
    if (!conversationId || !token) {
      setMessages([])
      return
    }
    setLoading(true)
    api<{ messages: Message[] }>(
      `/api/conversations/messages?conversationId=${encodeURIComponent(conversationId)}`,
      {},
      token
    )
      .then((r) => setMessages(r.messages))
      .catch(() => setMessages([]))
      .finally(() => setLoading(false))

    if (socket) {
      socket.emit('open-conversation', { conversationId })
      socket.on('new-message', (m: Message) => {
        if (m.conversationId === conversationId) {
          setMessages((prev) => (prev.find((x) => x.id === m.id) ? prev : [...prev, m]))
        }
      })
      socket.on('peer-typing', (data: { isTyping: boolean }) => {
        setPeerTyping(Boolean(data.isTyping))
        setPeerOnline(true)
      })
    }

    return () => {
      if (socket) {
        socket.off('new-message')
        socket.off('peer-typing')
        socket.emit('close-conversation', { conversationId })
      }
    }
  }, [conversationId, socket, token])

  useEffect(() => {
    if (!conversationId || !token) return
    api<{ conversations: ConversationListItem[] }>('/api/conversations/list', {}, token)
      .then((r) => {
        const c = r.conversations.find((c) => c.id === conversationId)
        if (!c) return
        const peer = user?.role === 'DOCTOR' ? c.patient : c.doctor
        const newPeerId = user?.role === 'DOCTOR' ? c.patient.id : c.doctor.id
        setPeerId(newPeerId)
        setPeerName(peer.name)
        setPeerPhone(peer.phone)
        setPeerRole(user?.role === 'DOCTOR' ? 'PATIENT' : 'DOCTOR')
        setPeerOnline(true)
        // Check block state
        setBlockCheckLoading(true)
        Promise.all([
          api<{ blocked: any[] }>('/api/block', {}, token).catch(() => ({ blocked: [] })),
        ]).then(([b]) => {
          const blockedList = b.blocked || []
          setIBlockedPeer(blockedList.some((x: any) => x.id === newPeerId))
        }).finally(() => setBlockCheckLoading(false))
      })
      .catch(() => null)
  }, [conversationId, token, user])

  // Auto-scroll to bottom whenever messages or typing changes
  useLayoutEffect(() => {
    if (!scrollRef.current) return
    const el = scrollRef.current
    // Use requestAnimationFrame to ensure DOM has painted
    const raf = requestAnimationFrame(() => {
      el.scrollTo({
        top: el.scrollHeight,
        behavior: reduce ? 'auto' : 'smooth',
      })
    })
    return () => cancelAnimationFrame(raf)
  }, [messages, peerTyping])

  // Also scroll immediately (instant) on first load to bottom without smooth animation
  useEffect(() => {
    if (!scrollRef.current) return
    scrollRef.current.scrollTop = scrollRef.current.scrollHeight
  }, [conversationId])

  const groupedMessages = useMemo(() => {
    const groups: { dayKey: string; dayLabel: string; messages: Message[] }[] = []
    for (const m of messages) {
      const dayKey = getDayKey(m.createdAt)
      const lastGroup = groups[groups.length - 1]
      if (!lastGroup || lastGroup.dayKey !== dayKey) {
        const label =
          dayKey === new Date().toISOString().slice(0, 10)
            ? 'امروز'
            : isToday(m.createdAt)
            ? 'امروز'
            : formatJalaliDay(m.createdAt)
        groups.push({ dayKey, dayLabel: label, messages: [m] })
      } else {
        lastGroup.messages.push(m)
      }
    }
    return groups
  }, [messages])

  const handleSend = async (raw?: string) => {
    const content = (raw ?? text).trim()
    if (!content || !token || !conversationId || !socket || !user) return
    setSending(true)
    try {
      const r = await api<{ message: Message }>(
        '/api/conversations/messages',
        {
          method: 'POST',
          body: JSON.stringify({ conversationId, content }),
        },
        token
      )
      setMessages((prev) => (prev.find((x) => x.id === r.message.id) ? prev : [...prev, r.message]))
      socket.emit('send-message', { conversationId, message: r.message })
      setText('')
      socket.emit('typing', { conversationId, isTyping: false })
    } catch (e: any) {
      toast.error(e.message || 'ارسال ناموفق بود')
    } finally {
      setSending(false)
    }
  }

  const handleTyping = (val: string) => {
    setText(val)
    if (socket && conversationId) {
      const now = Date.now()
      if (now - lastTypingRef.current > 500) {
        socket.emit('typing', { conversationId, isTyping: val.length > 0 })
        lastTypingRef.current = now
      }
    }
  }

  const handleEmojiSelect = (emoji: string) => {
    setText((prev) => prev + emoji)
    setEmojiOpen(false)
  }

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file || !token || !conversationId || !socket) return
    if (file.size > MAX_FILE_SIZE) {
      toast.error(`اندازه فایل باید کمتر از ${toPersianDigits(1)} مگابایت باشد`)
      return
    }
    setSending(true)
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const r = new FileReader()
        r.onload = () => resolve(String(r.result))
        r.onerror = () => reject(new Error('خواندن فایل ناموفق بود'))
        r.readAsDataURL(file)
      })
      const payload = JSON.stringify({
        _file: true,
        name: file.name,
        size: file.size,
        mime: file.type,
        data: dataUrl,
      })
      const r = await api<{ message: Message }>(
        '/api/conversations/messages',
        {
          method: 'POST',
          body: JSON.stringify({ conversationId, content: payload }),
        },
        token
      )
      setMessages((prev) => (prev.find((x) => x.id === r.message.id) ? prev : [...prev, r.message]))
      socket.emit('send-message', { conversationId, message: r.message })
      toast.success('فایل ارسال شد')
    } catch (e: any) {
      toast.error(e.message || 'ارسال فایل ناموفق بود')
    } finally {
      setSending(false)
    }
  }

  const handleClearChat = async () => {
    if (!token || !conversationId) return
    try {
      await api(`/api/conversations/clear?conversationId=${conversationId}`, { method: 'DELETE' }, token)
      setMessages([])
      setConfirmClear(false)
      toast.success('مکالمه پاک شد')
    } catch (e: any) {
      toast.error(e.message || 'پاکسازی ناموفق بود')
    }
  }

  const handleToggleBlock = async () => {
    if (!token || !peerId) return
    try {
      if (iBlockedPeer) {
        // unblock
        await api(`/api/block?blockedUserId=${peerId}`, { method: 'DELETE' }, token)
        setIBlockedPeer(false)
        toast.success('رفع مسدودیت انجام شد')
      } else {
        // block
        await api('/api/block', {
          method: 'POST',
          body: JSON.stringify({ blockedUserId: peerId }),
        }, token)
        setIBlockedPeer(true)
        toast.success('کاربر مسدود شد')
      }
    } catch (e: any) {
      toast.error(e.message || 'عملیات ناموفق بود')
    }
  }

  const quickReplies = user?.role === 'DOCTOR' ? QUICK_REPLIES_DOCTOR : QUICK_REPLIES_PATIENT

  if (!conversationId) {
    return (
      <Card className="p-0 flex flex-col items-center justify-center h-full text-muted-foreground bg-gradient-to-b from-teal-50/40 to-white border-dashed">
        <div className="size-20 rounded-2xl bg-teal-100 text-teal-600 grid place-items-center mb-4 shadow-md">
          <Send className="size-9" />
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-1">گفتگو را آغاز کنید</h3>
        <p className="text-sm max-w-xs text-center px-4">یک مکالمه را از لیست کنار انتخاب کنید تا گفتگو را شروع کنید.</p>
      </Card>
    )
  }

  return (
    <Card className="flex flex-col h-full p-0 overflow-hidden border-teal-100 shadow-md">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,.pdf,.doc,.docx,.txt,.zip"
        onChange={handleFileSelect}
        className="hidden"
      />

      {/* Header */}
      <div className="flex items-center gap-2 sm:gap-3 border-b p-2 sm:p-3 bg-gradient-to-l from-teal-50 to-white">
        {onBack && (
          <Button size="icon" variant="ghost" onClick={onBack} aria-label="بازگشت" className="shrink-0 size-9">
            <ArrowRight className="size-4" />
          </Button>
        )}
        <div className="relative shrink-0">
          <Avatar className="size-9 sm:size-11 ring-2 ring-teal-100">
            <AvatarFallback className="bg-gradient-to-br from-teal-500 to-emerald-600 text-white font-bold text-sm sm:text-base">
              {getInitials(peerName || '?')}
            </AvatarFallback>
          </Avatar>
          {peerOnline && (
            <span className="absolute -bottom-0.5 -left-0.5 size-2.5 sm:size-3 rounded-full bg-emerald-500 ring-2 ring-white" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold truncate text-sm sm:text-base">{peerName || '...'}</h3>
          <div className="flex items-center gap-2 text-[10px] sm:text-xs text-muted-foreground">
            {peerTyping ? (
              <span className="text-teal-600 flex items-center gap-1">
                <span className="flex gap-0.5">
                  {[0, 1, 2].map((i) => (
                    <motion.span
                      key={i}
                      className="size-1.5 rounded-full bg-teal-500"
                      animate={reduce ? {} : { y: [0, -2, 0] }}
                      transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
                    />
                  ))}
                </span>
                در حال نوشتن…
              </span>
            ) : peerOnline ? (
              <span className="flex items-center gap-1">
                <span className="size-1.5 rounded-full bg-emerald-500" /> آنلاین
              </span>
            ) : (
              <span>آفلاین</span>
            )}
            {peerRole && (
              <Badge variant="outline" className="text-[10px] py-0 hidden sm:inline-flex">
                {peerRole === 'DOCTOR' ? 'پزشک' : 'بیمار'}
              </Badge>
            )}
          </div>
        </div>
        {/* Three-dots dropdown only (call buttons removed) */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" aria-label="بیشتر" className="shrink-0">
              <MoreVertical className="size-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem onClick={() => setContactInfoOpen(true)}>
              <Info className="size-4 ml-2" /> اطلاعات تماس
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => toast.success('اعلان‌های این مکالمه قطع شد')}>
              <BellOff className="size-4 ml-2" /> قطع اعلان
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={handleToggleBlock}
              className={iBlockedPeer ? 'text-emerald-600 focus:text-emerald-700' : 'text-rose-600 focus:text-rose-700'}
            >
              {iBlockedPeer ? (
                <>
                  <ShieldCheck className="size-4 ml-2" /> رفع مسدودیت
                </>
              ) : (
                <>
                  <Ban className="size-4 ml-2" /> مسدود کردن کاربر
                </>
              )}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={() => setConfirmClear(true)}
              className="text-rose-600 focus:text-rose-700"
            >
              <Trash2 className="size-4 ml-2" /> پاک کردن مکالمه
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Messages - responsive height */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2 bg-[linear-gradient(to_bottom,#f8fafc,#ffffff)] h-[55vh] sm:h-[58vh] lg:h-[60vh]"
      >
        {loading && (
          <div className="flex items-center justify-center text-muted-foreground py-6">
            <Loader2 className="size-4 animate-spin ml-2" /> در حال بارگذاری…
          </div>
        )}
        {!loading && messages.length === 0 && (
          <div className="flex flex-col items-center justify-center text-muted-foreground py-10 text-center">
            <div className="size-16 rounded-full bg-teal-50 text-teal-600 grid place-items-center mb-3">
              <Smile className="size-8" />
            </div>
            <p className="font-medium text-foreground mb-1">پیامی وجود ندارد</p>
            <p className="text-xs">اولین پیام را شما بفرستید!</p>
          </div>
        )}

        <AnimatePresence initial={false}>
          {groupedMessages.map((group, gi) => (
            <div key={gi} className="space-y-2">
              <div className="flex items-center justify-center my-3">
                <div className="px-3 py-1 rounded-full bg-white shadow-sm text-[11px] text-muted-foreground border">
                  {group.dayLabel}
                </div>
              </div>
              {group.messages.map((m) => {
                const mine = m.senderId === user?.id
                const parsed = parseContent(m.content)
                const time = formatClockTime(m.createdAt)
                return (
                  <motion.div
                    key={m.id}
                    initial={reduce ? false : { opacity: 0, y: 8, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ duration: 0.25, ease: EASE }}
                    className={`flex ${mine ? 'justify-end' : 'justify-start'} items-end gap-2`}
                  >
                    {!mine && (
                      <Avatar className="size-6 sm:size-7 ring-1 ring-teal-50 shrink-0">
                        <AvatarFallback className="bg-teal-100 text-teal-700 text-[9px] sm:text-[10px] font-bold">
                          {getInitials(peerName)}
                        </AvatarFallback>
                      </Avatar>
                    )}
                    {parsed.kind === 'image' ? (
                      <div className={`max-w-[85%] sm:max-w-[60%] shadow-sm rounded-2xl overflow-hidden ${
                        mine ? 'rounded-bl-md' : 'rounded-br-md bg-white border'
                      }`}>
                        <img src={parsed.fileData} alt={parsed.fileName} className="w-full max-h-60 object-cover" />
                        <div className={`flex items-center gap-1 px-2 py-1 text-[10px] flex-wrap ${
                          mine ? 'bg-teal-700 text-white/80' : 'bg-white text-muted-foreground'
                        }`}>
                          <span className="truncate">{parsed.fileName} · {formatBytes(parsed.fileSize || 0)}</span>
                          <span className="mr-auto">{time}</span>
                          {mine && (m.isRead ? <CheckCheck className="size-3 text-sky-200" /> : <Check className="size-3" />)}
                        </div>
                      </div>
                    ) : parsed.kind === 'file' ? (
                      <div className={`max-w-[85%] sm:max-w-[75%] px-3 py-2 shadow-sm rounded-2xl flex items-center gap-2 ${
                        mine
                          ? 'bg-gradient-to-br from-teal-600 to-teal-700 text-white rounded-bl-md'
                          : 'bg-white border text-foreground rounded-br-md'
                      }`}>
                        <div className={`size-9 sm:size-10 rounded-lg grid place-items-center shrink-0 ${
                          mine ? 'bg-white/15' : 'bg-teal-100 text-teal-700'
                        }`}>
                          <FileText className="size-4 sm:size-5" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className={`text-xs sm:text-sm font-medium truncate ${mine ? 'text-white' : 'text-foreground'}`}>
                            {parsed.fileName}
                          </div>
                          <div className={`text-[10px] ${mine ? 'text-white/70' : 'text-muted-foreground'}`}>
                            {formatBytes(parsed.fileSize || 0)}
                          </div>
                          <div className={`flex items-center gap-1 text-[10px] mt-0.5 ${mine ? 'text-white/70' : 'text-muted-foreground'}`}>
                            <span>{time}</span>
                            {mine && (m.isRead ? <CheckCheck className="size-3 text-sky-200" /> : <Check className="size-3" />)}
                          </div>
                        </div>
                        <a
                          href={parsed.fileData}
                          download={parsed.fileName}
                          className={`size-8 grid place-items-center rounded-md transition shrink-0 ${
                            mine ? 'hover:bg-white/20' : 'hover:bg-teal-50'
                          }`}
                          aria-label="دانلود"
                        >
                          <Download className="size-4" />
                        </a>
                      </div>
                    ) : (
                      <div className={`max-w-[85%] sm:max-w-[78%] px-3 py-2 text-sm whitespace-pre-wrap break-words shadow-sm ${
                        mine
                          ? 'bg-gradient-to-br from-teal-600 to-teal-700 text-white rounded-2xl rounded-bl-md'
                          : 'bg-white border text-foreground rounded-2xl rounded-br-md'
                      }`}>
                        <div>{parsed.text || m.content}</div>
                        <div className={`flex items-center gap-1 text-[10px] mt-1 ${mine ? 'text-white/70' : 'text-muted-foreground'}`}>
                          <span>{time}</span>
                          {mine && (m.isRead ? <CheckCheck className="size-3 text-sky-200" /> : <Check className="size-3" />)}
                        </div>
                      </div>
                    )}
                  </motion.div>
                )
              })}
            </div>
          ))}
        </AnimatePresence>

        <AnimatePresence>
          {peerTyping && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              className="flex justify-start items-end gap-2"
            >
              <Avatar className="size-6 sm:size-7 ring-1 ring-teal-50 shrink-0">
                <AvatarFallback className="bg-teal-100 text-teal-700 text-[9px] sm:text-[10px] font-bold">
                  {getInitials(peerName)}
                </AvatarFallback>
              </Avatar>
              <div className="bg-white border rounded-2xl rounded-br-md px-3 py-3 shadow-sm">
                <span className="flex gap-1">
                  {[0, 1, 2].map((i) => (
                    <motion.span
                      key={i}
                      className="size-2 rounded-full bg-teal-400"
                      animate={reduce ? {} : { y: [0, -3, 0], opacity: [0.4, 1, 0.4] }}
                      transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15 }}
                    />
                  ))}
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Block banner */}
      <AnimatePresence>
        {iBlockedPeer && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="px-3 py-2 bg-rose-50 border-t border-rose-200 text-rose-700 text-xs flex items-center justify-between gap-2"
          >
            <span className="flex items-center gap-1.5">
              <Ban className="size-3.5" />
              شما این کاربر را مسدود کرده‌اید. برای ارسال پیام، رفع مسدودیت کنید.
            </span>
            <button
              onClick={handleToggleBlock}
              className="text-emerald-700 hover:text-emerald-800 font-medium whitespace-nowrap"
            >
              رفع مسدودیت
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Quick replies */}
      <AnimatePresence>
        {!text && messages.length > 0 && !iBlockedPeer && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="px-3 py-2 border-t bg-white overflow-x-auto flex gap-2"
          >
            {quickReplies.map((q) => (
              <button
                key={q}
                onClick={() => handleSend(q)}
                className="whitespace-nowrap text-xs px-3 py-1.5 rounded-full border border-teal-200 bg-teal-50 text-teal-700 hover:bg-teal-100 transition"
              >
                {q}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input - mobile friendly */}
      <div className="p-2 sm:p-3 border-t flex items-center gap-1.5 sm:gap-2 bg-white relative">
        <Button
          variant="ghost"
          size="icon"
          aria-label="پیوست فایل"
          className="text-muted-foreground shrink-0 size-9 hover:bg-teal-50 hover:text-teal-600"
          onClick={() => fileInputRef.current?.click()}
          disabled={sending}
        >
          <Paperclip className="size-5" />
        </Button>
        <Popover open={emojiOpen} onOpenChange={setEmojiOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              aria-label="ایموجی"
              className="text-muted-foreground shrink-0 size-9 hover:bg-amber-50 hover:text-amber-600"
            >
              <Smile className="size-5" />
            </Button>
          </PopoverTrigger>
          <PopoverContent side="top" align="start" className="p-0 w-auto border-0 bg-transparent shadow-none">
            <div className="absolute bottom-2 right-0">
              <EmojiPicker onSelect={handleEmojiSelect} onClose={() => setEmojiOpen(false)} />
            </div>
          </PopoverContent>
        </Popover>
        <Input
          placeholder="پیام خود را بنویسید…"
          value={text}
          onChange={(e) => handleTyping(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault()
              handleSend()
            }
          }}
          disabled={sending}
          className="flex-1 rounded-full bg-muted/40 border-0 focus-visible:ring-1 focus-visible:ring-teal-400 text-sm sm:text-base min-w-0"
        />
        <Button
          onClick={() => handleSend()}
          disabled={sending || !text.trim()}
          size="icon"
          className="rounded-full bg-gradient-to-br from-teal-500 to-teal-700 hover:opacity-90 shrink-0 size-9 sm:size-10 shadow-md"
          aria-label="ارسال"
        >
          {sending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
        </Button>
      </div>

      {/* Confirm clear dialog */}
      <Dialog open={confirmClear} onOpenChange={setConfirmClear}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>پاک کردن مکالمه؟</DialogTitle>
            <DialogDescription>
              تمام پیام‌های این مکالمه برای همیشه حذف می‌شوند. این عمل قابل بازگشت نیست.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmClear(false)}>انصراف</Button>
            <Button variant="destructive" onClick={handleClearChat}>
              <Trash2 className="size-4 ml-2" /> پاک کن
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Contact info dialog */}
      <Dialog open={contactInfoOpen} onOpenChange={setContactInfoOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>اطلاعات تماس</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col items-center gap-3 py-4">
            <Avatar className="size-20 ring-4 ring-teal-100">
              <AvatarFallback className="bg-gradient-to-br from-teal-500 to-emerald-600 text-white text-2xl font-bold">
                {getInitials(peerName)}
              </AvatarFallback>
            </Avatar>
            <div className="text-center">
              <div className="font-semibold text-lg">{peerName}</div>
              <div className="text-sm text-muted-foreground">
                {peerRole === 'DOCTOR' ? 'پزشک' : 'بیمار'}
              </div>
            </div>
            <div className="w-full border-t pt-3 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">شماره تماس</span>
                <span dir="ltr" className="font-medium">{toPersianDigits(peerPhone)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">وضعیت</span>
                <span className="text-emerald-600 font-medium flex items-center gap-1">
                  <span className="size-1.5 rounded-full bg-emerald-500" /> آنلاین
                </span>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setContactInfoOpen(false)}>بستن</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
